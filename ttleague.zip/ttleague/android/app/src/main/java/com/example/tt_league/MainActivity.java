package com.example.tt_league;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
