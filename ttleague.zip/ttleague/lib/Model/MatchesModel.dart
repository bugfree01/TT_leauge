import 'package:tt_league/helper/app_utilities/appImages.dart';

class MatchModel{
  String image;
  String name;
  MatchModel(this.image, this.name);
}

List<MatchModel> matchesList=[
  MatchModel(AppImages.player1, "MA Long"),
  MatchModel(AppImages.player2, "Xu Xin"),
  MatchModel(AppImages.player3, "Ryoma"),
  MatchModel(AppImages.player4, "MA Lin"),
  MatchModel(AppImages.player5, "Fan Long"),
  MatchModel(AppImages.player2, "Xu Xin"),
  MatchModel(AppImages.player3, "Ryoma"),
  MatchModel(AppImages.player4, "MA Lin"),
  MatchModel(AppImages.player5, "Fan Long"),
  MatchModel(AppImages.player1, "MA Long"),
  MatchModel(AppImages.player2, "Xu Xin"),
  MatchModel(AppImages.player3, "Ryoma"),
  MatchModel(AppImages.player4, "MA Lin"),
  MatchModel(AppImages.player5, "Fan Long"),
  MatchModel(AppImages.player2, "Xu Xin"),
  MatchModel(AppImages.player3, "Ryoma"),
  MatchModel(AppImages.player4, "MA Lin"),
  MatchModel(AppImages.player5, "Fan Long"),
];