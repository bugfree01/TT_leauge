class StatisticModel{
  String table;
  String users;
  String teams;
  String tournaments;
  String requests;

  StatisticModel(
      {this.table = "",
      this.users = "",
      this.teams = "",
      this.tournaments = "",
      this.requests = ""});
}