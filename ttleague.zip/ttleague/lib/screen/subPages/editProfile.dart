import 'dart:io';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:image_picker/image_picker.dart';
import 'package:tt_league/Model/userModel.dart';
import 'package:tt_league/cubit/profile/editProfile/edit_profile_cubit.dart';
import 'package:tt_league/helper/app_utilities/appImages.dart';
import 'package:tt_league/helper/app_utilities/app_theme.dart';
import 'package:tt_league/helper/app_utilities/colors.dart';
import 'package:tt_league/helper/app_utilities/method_utils.dart';
import 'package:tt_league/helper/app_utilities/size_reziser.dart';
import 'package:tt_league/screen/customWidget/app_circular_loader.dart';
import 'package:tt_league/screen/customWidget/dxWidget/dx_center_text.dart';
import 'package:tt_league/screen/customWidget/dxWidget/dx_input_fields.dart';
import 'package:tt_league/screen/customWidget/dxWidget/dx_text.dart';

class EditProfile extends StatefulWidget {
  @override
  _EditProfileState createState() => _EditProfileState();
}

class _EditProfileState extends State<EditProfile> {
  TextEditingController name = TextEditingController();
  TextEditingController mobileController = TextEditingController();
  TextEditingController genderController = TextEditingController();
  TextEditingController locationController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController repeatPasswordController = TextEditingController();
  TextEditingController aboutController = TextEditingController();
  TextEditingController shirtController = TextEditingController();
  TextEditingController shirtRedeemController = TextEditingController();
  TextEditingController timeController = TextEditingController();
  TextEditingController ageController = TextEditingController();
  TextEditingController pLocationController = TextEditingController();

  File? _image1, _image2, _image3, _image4, _image5, _image6;

  String image1 = "", image2 = "", image3 = "", image4 = "", image5 = "",
      image6 = "";

  late Size size;
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  profileStatus? selectedTemp;
  late UserModel userModel;
  bool paswwordHiden = true;

  @override
  void initState() {
    BlocProvider.of<EditProfileCubit>(context).getUSerData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    SizeConfig().init(context);
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        elevation: 0,
        // automaticallyImplyLeading: false,
        title: DxText(
          "Edit Profile",
          mSize: 35,
          mBold: true,
          textColor: Colors.white,
        ),
        backgroundColor: black_grey,
      ),
      body: BlocConsumer<EditProfileCubit, EditProfileState>(
          builder: (BuildContext context, state) {
        if (state is EditProfileLoaded) {
          return body();
        }

        if (state is EditProfileInitial) {
          return AppLoaderProgress();
          // return body();
        }
        if (state is EditProfileError) {
          return body();
        }
        if (state is EditProfileLoading) {
          return Stack(
            children: [body(), AppLoaderProgress()],
          );
        }

        return Container();
      }, listener: (BuildContext context, state) {
        if (state is EditProfileError) {
          MethodUtils.showSnackBarGK(_scaffoldKey, "${state.error}");
        }
        if (state is EditProfileLoaded) {
          this.userModel = state.userModel;
          if (state.userModel != null) {
            name.text = state.userModel.fullname!;
            passwordController.text = state.userModel.keycol!;
            mobileController.text = state.userModel.mobile;
            locationController.text = state.userModel.location!;
            repeatPasswordController.text = state.userModel.keycol!;
            shirtController.text = state.userModel.tshirt!;
            shirtRedeemController.text = state.userModel.shirtRedeemed!;
            timeController.text = state.userModel.preftime!;
            ageController.text = state.userModel.age!;
            aboutController.text = state.userModel.description!;
            pLocationController.text = state.userModel.preflocation!;
            image1 = state.userModel.image1;
            image2 = state.userModel.image2;
            image3 = state.userModel.image3;
            image4 = state.userModel.image4;
            image5 = state.userModel.image5;
            image6 = state.userModel.image6;
          }
          if (state.msg != null) {
            MethodUtils.showSnackBarGK(_scaffoldKey, "${state.msg}");
          }
        }
      }),
    );
  }

  Widget body() {
    double mainContainer = SizeConfig.blockSizeVertical * 70;
    double firstImageContainer = SizeConfig.blockSizeVertical * 40;
    double imageWidth = SizeConfig.blockSizeHorizontal * 36.5;
    print("height is $imageWidth"); //480//273
    return SingleChildScrollView(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: mainContainer,
            color: Colors.blueGrey[50],
            padding: EdgeInsets.all(8),
            child: Column(
              children: [
                Container(
                  height: firstImageContainer,
                  child: Row(
                    children: [
                      Stack(
                        children: [
                          InkWell(
                            onTap: getImage1,
                            child: Container(
                              height: firstImageContainer,
                              width: size.width / 2,
                              decoration: BoxDecoration(
                                border:
                                    Border.all(color: Colors.black, width: 0.1),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: ClipRRect(
                                borderRadius:
                                    BorderRadius.all(Radius.circular(10)),
                                child: (_image1 == null
                                    ? (userModel.image1.isNotEmpty
                                        ? CachedNetworkImage(
                                            imageUrl:
                                                "http://www.sipconline.com/uat/sipl/images/${userModel.image1}",
                                            placeholder: (context, url) =>
                                                CupertinoActivityIndicator(),
                                            fit: BoxFit.cover,
                                            errorWidget:
                                                (context, url, error) =>
                                                    Icon(Icons.error),
                                          )
                                        : Center(
                                            child: Icon(
                                              Icons.add,
                                              color: Colors.black,
                                            ),
                                          ))
                                    : Image.file(
                                        _image1!,
                                        fit: BoxFit.cover,
                                      )),
                              ),
                            ),
                          ),
                          Positioned(
                              bottom: 8,
                              right: 8,
                              child: CircleAvatar(
                                radius: 15,
                                backgroundColor: Colors.white,
                                child: DxTextBlack(
                                  "1",
                                  mBold: true,
                                  mSize: 22,
                                ),
                              ))
                        ],
                      ),
                      Expanded(
                        child: Container(
                          width: size.width,
                          margin: EdgeInsets.only(left: 8),
                          child: Column(
                            children: [
                              Stack(
                                children: [
                                  InkWell(
                                    onTap: getImage2,
                                    child: Container(
                                      height: firstImageContainer / 2,
                                      width: imageWidth,
                                      decoration: BoxDecoration(
                                        border: Border.all(
                                            color: Colors.black, width: 0.1),
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: ClipRRect(
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(10)),
                                          child: (_image2 == null
                                              ? (userModel.image2.isNotEmpty
                                                  ? CachedNetworkImage(
                                                      imageUrl: "http://www"
                                                          ".sipconline"
                                                          ".com/uat/sipl/images/${userModel.image2}",
                                                      fit: BoxFit.cover,
                                                      placeholder: (context,
                                                              url) =>
                                                          CupertinoActivityIndicator(),
                                                      errorWidget: (context,
                                                              url, error) =>
                                                          Icon(Icons.error),
                                                    )
                                                  : Center(
                                                      child: Icon(
                                                        Icons.add,
                                                        color: Colors.black,
                                                      ),
                                                    ))
                                              : Image.file(
                                                  _image2!,
                                                  fit: BoxFit.cover,
                                                ))),
                                    ),
                                  ),
                                  Positioned(
                                      bottom: 8,
                                      right: 8,
                                      child: CircleAvatar(
                                        radius: 15,
                                        backgroundColor: Colors.white,
                                        child: DxTextBlack(
                                          "2",
                                          mBold: true,
                                          mSize: 22,
                                        ),
                                      ))
                                ],
                              ),
                              Stack(
                                children: [
                                  InkWell(
                                    onTap: getImage3,
                                    child: Container(
                                      margin: EdgeInsets.only(top: 8),
                                      height: firstImageContainer / 2.25,
                                      width: imageWidth,
                                      decoration: BoxDecoration(
                                        border: Border.all(
                                            color: Colors.black, width: 0.1),
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: ClipRRect(
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(10)),
                                        child: (_image3 == null
                                            ? (userModel.image3.isNotEmpty
                                                ? CachedNetworkImage(
                                                    imageUrl: "http://www"
                                                        ".sipconline"
                                                        ""
                                                        ".com/uat/sipl/images/${userModel.image3}",
                                                    fit: BoxFit.cover,
                                                    placeholder: (context,
                                                            url) =>
                                                        CupertinoActivityIndicator(),
                                                    errorWidget:
                                                        (context, url, error) =>
                                                            Icon(Icons.error),
                                                  )
                                                : Center(
                                                    child: Icon(
                                                      Icons.add,
                                                      color: Colors.black,
                                                    ),
                                                  ))
                                            : Image.file(_image3!)),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                      bottom: 8,
                                      right: 8,
                                      child: CircleAvatar(
                                        radius: 15,
                                        backgroundColor: Colors.white,
                                        child: DxTextBlack(
                                          "3",
                                          mBold: true,
                                          mSize: 22,
                                        ),
                                      ))
                                ],
                              ),
                            ],
                          ),
                        ),
                      )
                    ],
                  ),
                ),
                Expanded(
                    child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Expanded(
                        child: Stack(
                      children: [
                        InkWell(
                          onTap: getImage4,
                          child: Container(
                            height: firstImageContainer / 1.6,
                            decoration: BoxDecoration(
                              border:
                                  Border.all(color: Colors.black, width: 0.1),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: ClipRRect(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(10)),
                              child: (_image4 == null
                                  ? (userModel.image4.isNotEmpty
                                      ? CachedNetworkImage(
                                          imageUrl: "http://www"
                                              ".sipconline"
                                              ".com/uat/sipl/images/${userModel.image4}",
                                          fit: BoxFit.cover,
                                          placeholder: (context, url) =>
                                              CupertinoActivityIndicator(),
                                          errorWidget: (context, url, error) =>
                                              Icon(Icons.error),
                                        )
                                      : Center(
                                          child: Icon(
                                            Icons.add,
                                            color: Colors.black,
                                          ),
                                        ))
                                  : Image.file(_image4!,fit: BoxFit.cover,)),
                            ),
                          ),
                        ),
                        Positioned(
                            bottom: 8,
                            right: 8,
                            child: CircleAvatar(
                              radius: 15,
                              backgroundColor: Colors.white,
                              child: DxTextBlack(
                                "4",
                                mBold: true,
                                mSize: 22,
                              ),
                            ))
                      ],
                    )),
                    Expanded(
                        child: Stack(
                      children: [
                        InkWell(
                          onTap: getImage5,
                          child: Container(
                            height: firstImageContainer / 1.6,
                            margin: EdgeInsets.only(left: 5),
                            decoration: BoxDecoration(
                              border:
                                  Border.all(color: Colors.black, width: 0.1),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: ClipRRect(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(10)),
                              child: (_image5 == null
                                  ? (userModel.image5.isNotEmpty
                                      ? CachedNetworkImage(
                                          imageUrl: "http://www"
                                              ".sipconline"
                                              ".com/uat/sipl/images/${userModel.image5}",
                                          fit: BoxFit.cover,
                                          placeholder: (context, url) =>
                                              CupertinoActivityIndicator(),
                                          errorWidget: (context, url, error) =>
                                              Icon(Icons.error),
                                        )
                                      : Center(
                                          child: Icon(
                                            Icons.add,
                                            color: Colors.black,
                                          ),
                                        ))
                                  : Image.file(_image5!,fit: BoxFit.cover,)),
                            ),
                          ),
                        ),
                        Positioned(
                            bottom: 8,
                            right: 8,
                            child: CircleAvatar(
                              radius: 15,
                              backgroundColor: Colors.white,
                              child: DxTextBlack(
                                "5",
                                mBold: true,
                                mSize: 22,
                              ),
                            ))
                      ],
                    )),
                    Expanded(
                        child: Stack(
                      children: [
                        InkWell(
                          onTap: getImage6,
                          child: Container(
                            height: firstImageContainer / 1.6,
                            margin: EdgeInsets.only(left: 5),
                            decoration: BoxDecoration(
                              border:
                                  Border.all(color: Colors.black, width: 0.1),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: ClipRRect(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(10)),
                              child: (_image6 == null
                                  ? (userModel.image6.isNotEmpty
                                      ? CachedNetworkImage(
                                          imageUrl: "http://www"
                                              ".sipconline"
                                              ".com/uat/sipl/images/${userModel.image6}",
                                          fit: BoxFit.cover,
                                          placeholder: (context, url) =>
                                              CupertinoActivityIndicator(),
                                          errorWidget: (context, url, error) =>
                                              Icon(Icons.error),
                                        )
                                      : Center(
                                          child: Icon(
                                            Icons.add,
                                            color: Colors.black,
                                          ),
                                        ))
                                  : Image.file(_image6!, fit: BoxFit.cover,)),
                            ),
                          ),
                        ),
                        Positioned(
                            bottom: 8,
                            right: 8,
                            child: CircleAvatar(
                              radius: 15,
                              backgroundColor: Colors.white,
                              child: DxTextBlack(
                                "6",
                                mBold: true,
                                mSize: 22,
                              ),
                            ))
                      ],
                    )),
                  ],
                ))
              ],
            ),
          ),
          formField("Name", name),
          Divider(
            color: Colors.black26,
          ),
          formField("Phone Number", mobileController,keyboardType:  TextInputType.number),

          Divider(
            color: Colors.black26,
          ),
          formField("Current Location", locationController),
          Divider(
            color: Colors.black26,
          ),

          formField(
            "Password",
            passwordController,
            obscureText: paswwordHiden,
            eyeShow: true
          ),
          Divider(
            color: Colors.black26,
          ),
          // formField("Repeat Password", passwordController),
          // Divider(
          //   color: Colors.black26,
          // ),
          formField("Shirt", shirtController),
          Divider(
            color: Colors.black26,
          ),
          // formField("Shirt Redeemed", shirtRedeemController,keyboardType:  TextInputType.number),
          // Divider(
          //   color: Colors.black26,
          // ),
          formField("Preferred Location", pLocationController),
          Divider(
            color: Colors.black26,
          ),
          formField("Preferred Time", timeController),
          Divider(
            color: Colors.black26,
          ),
          formField("Age", ageController,keyboardType:  TextInputType.number),
          Divider(
            color: Colors.black26,
          ),
          buildHeading('About'),
          TextField(
            controller: aboutController,
            maxLines: 3,
            minLines: 2,
            decoration: new InputDecoration(
              border: InputBorder.none,
              focusedBorder: InputBorder.none,
              enabledBorder: InputBorder.none,
              errorBorder: InputBorder.none,
              disabledBorder: InputBorder.none,
              contentPadding:
                  EdgeInsets.only(left: 15, bottom: 11, top: 11, right: 15),
            ),
          ),
          Divider(
            color: Colors.black26,
          ),

          SizedBox(height: 20),
          Center(child: buildSubmitButton(context)),
          SizedBox(height: 20),
        ],
      ),
    );
  }

  Widget formField(String title, TextEditingController? controller,
      {bool obscureText = false,TextInputType? keyboardType = TextInputType
          .emailAddress,bool eyeShow = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        Expanded(flex: 1, child: buildHeading(title)),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.only(right: 16),
            child: TextField(
              controller: controller,
              obscureText: obscureText,
              keyboardType:keyboardType ,
              decoration: new InputDecoration(
                suffixIcon:eyeShow ? IconButton(
                  color: Colors.black,
                  icon: paswwordHiden ? Icon(Icons.visibility_off):Icon(Icons.visibility),
                  onPressed: (){
                    setState(() {
                      paswwordHiden=!paswwordHiden;
                    });
                  },
                ):null,
                border: InputBorder.none,
                focusedBorder: InputBorder.none,
                enabledBorder: InputBorder.none,
                errorBorder: InputBorder.none,
                disabledBorder: InputBorder.none,
                contentPadding:
                    EdgeInsets.only(left: 15, bottom: 11, top: 11, right: 15),
              ),
            ),
          ),
        )
      ],
    );
  }


  Padding buildHeading(String? title) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: DxTextBlack(
        title!,
        mSize: 20,
        mBold: true,
      ),
    );
  }

  Padding buildBody({String? title, Color? color, bool bold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: DxText(
        title!,
        textColor: color!,
        mSize: 18,
        mBold: bold,
        maxLines: 6,
      ),
    );
  }

  Container buildSubmitButton(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width - 150,
      child: RaisedButton(
        elevation: 8.0,
        onPressed: onClick,
        color: materialAccentColor,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 14),
          child: DxTextWhiteM(
            'Save',
            mBold: true,
            mSize: 18,
          ),
        ),
      ),
    );
  }

  onClick() {
    UserModel userModel = UserModel(
        fullname: name.text,
        mobile: mobileController.text,
        keycol: passwordController.text,
        cPass: repeatPasswordController.text,
        location: locationController.text,
        shirtRedeemed: "",
        age: ageController.text,
        description: aboutController.text,
        tshirt: shirtController.text,
        preftime: timeController.text,
        preflocation: pLocationController.text,
        playerimage: [image1,image2,image3,image4,image5,image6]);
    BlocProvider.of<EditProfileCubit>(context).updateUserData(userModel);
  }

  Future getImage1() async {
    ImagePicker.pickImage(source: ImageSource.gallery).then((imgFile) {
      image1 = imgFile.path;
      print("your image path is ${imgFile.path}");
      _image1 = File(imgFile.path);
      setState(() {});
    });
  }

  Future getImage2() async {
    ImagePicker.pickImage(source: ImageSource.gallery).then((imgFile) {
      image2 = imgFile.path;
      print("your image path is ${imgFile.path}");
      _image2 = File(imgFile.path);
      setState(() {});
    });
  }

  Future getImage3() async {
    ImagePicker.pickImage(source: ImageSource.gallery).then((imgFile) {
      image3 = imgFile.path;
      print("your image path is ${imgFile.path}");
      _image3 = File(imgFile.path);
      setState(() {});
    });
  }

  Future getImage4() async {
    ImagePicker.pickImage(source: ImageSource.gallery).then((imgFile) {
      image4 = imgFile.path;
      print("your image path is ${imgFile.path}");
      _image4 = File(imgFile.path);
      setState(() {});
    });
  }

  Future getImage5() async {
    ImagePicker.pickImage(source: ImageSource.gallery).then((imgFile) {
      image5 = imgFile.path;
      print("your image path is ${imgFile.path}");
      _image5 = File(imgFile.path);
      setState(() {});
    });
  }

  Future getImage6() async {
    ImagePicker.pickImage(source: ImageSource.gallery).then((imgFile) {
      image6 = imgFile.path;
      print("your image path is ${imgFile.path}");
      _image6 = File(imgFile.path);
      setState(() {});
    });
  }
}

class profileStatus {
  String status;

  profileStatus(this.status);
}

List<profileStatus> profileStatusList = [
  profileStatus("Active"),
  profileStatus("UnActive"),
];

class TemplateBottomSheet extends StatelessWidget {
  List<profileStatus> templList;
  profileStatus? selectedTemp;
  Function(profileStatus)? onTempChanged;

  TemplateBottomSheet(this.templList,
      {Key? key, this.onTempChanged, this.selectedTemp})
      : super(key: UniqueKey());

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
          height: this.templList.length <= 3
              ? 250
              : (MediaQuery.of(context).size.height * 0.65),
          color: Colors.white,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              ListTile(
                title: DxTextBlack(
                  "Select Template",
                  mBold: true,
                ),
                trailing: IconButton(
                  icon: Icon(Icons.clear),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                ),
              ),
              Divider(),
              Expanded(
                  child: this.templList.isEmpty
                      ? DxCenterText(
                          displayText: "No Status Found",
                        )
                      : ListView.separated(
                          itemCount: this.templList.length,
                          itemBuilder: (BuildContext context, int index) =>
                              InkWell(
                            onTap: () {
                              if (this.onTempChanged != null) {
                                this.onTempChanged!(this.templList[index]);
                                Navigator.pop(context);
                                //setState(() {});
                              }
                            },
                            child: Container(
                              //margin: EdgeInsets.only(left: 4),
                              decoration: this.selectedTemp != null &&
                                      this.selectedTemp!.status ==
                                          this.templList[index].status
                                  ? BoxDecoration(
                                      color:
                                          Colors.grey.shade400.withOpacity(0.7),
                                      //borderRadius: BorderRadius.only(topLeft: Radius.circular(35), bottomLeft: Radius.circular(35)),
                                    )
                                  : null,

                              child: Container(
                                margin: EdgeInsets.only(
                                    left: 8, right: 8, top: 4, bottom: 4),
                                padding: EdgeInsets.only(
                                    left: 10, right: 10, top: 10, bottom: 8),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    SizedBox(
                                      child: DxTextBlack("${index + 1} - "),
                                      width: 35,
                                    ),
                                    Expanded(
                                      child: Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          DxTextBlack(
                                            this.templList[index].status,
                                            mBold: true,
                                            fontWeight: FontWeight.w500,
                                          ),
                                        ],
                                      ),
                                      flex: 8,
                                    ),
                                    Expanded(
                                      child: this.selectedTemp != null &&
                                              this.selectedTemp!.status ==
                                                  this.templList[index].status
                                          ? Icon(Icons.album_sharp,
                                              color: materialAccentColor)
                                          : Icon(Icons.adjust_sharp,
                                              color: Colors.grey.shade400),
                                      flex: 1,
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                          separatorBuilder: (BuildContext context, int index) =>
                              Container(
                            height: 1,
                            width: double.infinity,
                          ),
                        ))
            ],
          )),
    );
  }
}

// Row(
//   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//   children: [
//     Expanded(flex: 1, child: buildHeading("Profile Status")),
//     Expanded(
//       child: Padding(
//         padding: const EdgeInsets.only(right: 16),
//         child: Container(
//           // height: 75,
//           // // padding: EdgeInsets.only(left: 8, right: 8),
//           // color: Colors.white,
//           alignment: Alignment.center,
//           child: DxDropDown(
//               borderColor: textColorPrimary,
//               boundaryEnable: false,
//               hintText: "Active",
//               valueText:
//                   selectedTemp != null ? selectedTemp!.status : "",
//               isSemiBold: selectedTemp != null,
//               onClick: () {
//                 print("hello");
//                 openTemplateBottomSheet(profileStatusList, context);
//               }),
//         ),
//       ),
//     )
//   ],
// ),
// Divider(
//   color: Colors.black26,
// ),
// Row(
//   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//   children: [
//     Expanded(flex: 1, child: buildHeading("T-Shirt")),
//     Expanded(
//       child: Padding(
//         padding: const EdgeInsets.only(right: 16),
//         child: Container(
//           alignment: Alignment.center,
//           child: DxDropDown(
//               borderColor: textColorPrimary,
//               boundaryEnable: false,
//               hintText: "Active",
//               valueText: "",
//               isSemiBold: null,
//               onClick: () {}),
//         ),
//       ),
//     )
//   ],
// ),
