import 'package:flutter/material.dart';
import 'package:tt_league/Model/matchRequestModel.dart';
import 'package:tt_league/cubit/matchRequest/matchRequest.dart';
import 'package:tt_league/helper/app_utilities/appImages.dart';
import 'package:tt_league/helper/app_utilities/app_theme.dart';
import 'package:tt_league/helper/app_utilities/colors.dart';
import 'package:tt_league/helper/app_utilities/method_utils.dart';
import 'package:tt_league/network_configs/networkRequest.dart';
import 'package:tt_league/screen/customWidget/app_circular_loader.dart';
import 'package:tt_league/screen/customWidget/dailog/cancelMatch.dart';
import 'package:tt_league/screen/customWidget/dailog/enterScore.dart';
import 'package:tt_league/screen/customWidget/dxWidget/dx_text.dart';

enum ScreenTypes { request, pending, completed }

class MatchDetailsScreen extends StatefulWidget {
  Requests opponentData;
  ScreenTypes screenTypes;

  MatchDetailsScreen(this.opponentData, {required this.screenTypes});

  @override
  _MatchDetailsScreenState createState() => _MatchDetailsScreenState();
}

class _MatchDetailsScreenState extends State<MatchDetailsScreen> {
  MatchRequestRepo matchRequestRepo =
      MatchRequestRepo(networkRequest: NetworkRequest());
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  bool isLoading = false;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(100.0),
        child: AppBar(
          elevation: 0,
          leading: IconButton(
            onPressed: () => Navigator.pop(context),
            icon: Icon(Icons.arrow_back_ios),
            color: Colors.grey,
            iconSize: 30,
          ),
          title: DxText(
            "Match Details",
            mSize: 35,
            mBold: true,
            textColor: Colors.white,
          ),
          backgroundColor: black_grey,
          actions: <Widget>[
            // Padding(
            //   padding: const EdgeInsets.symmetric(horizontal: 12, vertical:10),
            //   child: FloatingActionButton(
            //     backgroundColor: Colors.grey.shade600,
            //     foregroundColor: Colors.black,
            //     mini: true,
            //     onPressed: () {
            //       // Respond to button press
            //     },
            //     child: Icon(
            //       Icons.menu,
            //       color: Colors.white,
            //     ),
            //   ),
            // )
          ],
        ),
      ),
      body: Stack(children: [
        body(),
        isLoading ? Center(child: AppLoaderProgress(),):SizedBox.shrink()
      ],),
    );
  }

  Widget body() {
    String image = widget.opponentData.opponent!.playerimage!.split("/").last;
    return SingleChildScrollView(
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: DxText(
              'Match ID: ${widget.opponentData.requestid}',
              mBold: true,
              mSize: 22,
              textColor: Colors.grey,
            ),
          ),
          Container(
            alignment: Alignment.center,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircleAvatar(
                  radius: 40,
                  backgroundImage: NetworkImage("http://www"
                      ".sipconline.com/uat/sipl/images/$image"),
                ),
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      DxTextBlack(
                        widget.opponentData.opponent!.fullname ?? "",
                        mBold: true,
                        mSize: 18,
                        overflow: TextOverflow.ellipsis,
                      ),
                      SizedBox(height: 15),
                      DxText(
                        widget.opponentData.opponent!.location ?? "",
                        overflow: TextOverflow.ellipsis,
                        textColor: Colors.grey,
                      ),
                      // buildHeading(widget.opponentData.opponent!.fullname),
                      // buildBody(title:widget.opponentData.opponent!.location, color:
                      // Colors.grey),
                    ],
                  ),
                ),
              ],
            ),
          ),
          SizedBox(height: 20),
          Container(
            margin: const EdgeInsets.all(16.0),
            padding: const EdgeInsets.all(16.0),
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12.0),
                boxShadow: [
                  BoxShadow(
                    color: Color(0xff000000).withOpacity(0.2),
                    blurRadius: 5.0,
                  ),
                ]),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                buildTopCounterCard(
                    title: 'Winning',
                    value: '${widget.opponentData.opponent!.percentage}%'),
                buildTopCounterCard(
                    title: 'Wins',
                    value: widget.opponentData.opponent!.wins.toString()),
                buildTopCounterCard(
                    title: 'Matches',
                    value: widget.opponentData.opponent!.matches.toString()),
              ],
            ),
          ),
          Container(
            margin: const EdgeInsets.all(16.0),
            padding: const EdgeInsets.all(16.0),
            width: MediaQuery.of(context).size.width,
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12.0),
                boxShadow: [
                  BoxShadow(
                    color: Color(0xff000000).withOpacity(0.2),
                    blurRadius: 5.0,
                  ),
                ]),
            child: buildTopCounterCard(
                title: 'Match Date',
                value: widget.opponentData.scheduledat ?? ""),
          ),
          SizedBox(height: 40),
         ( widget.screenTypes == ScreenTypes.pending ? buildButton(context, btnName: 'Enter Scores', onPressed: () {
            showDialog(
                context: context,
                builder: (BuildContext context) => EnterScrore());
          }) :widget.screenTypes == ScreenTypes.completed
              ? SizedBox.shrink() : buildButton(context, btnName: 'Accepted', onPressed:acceptMAtch)),
          widget.screenTypes == ScreenTypes.completed
              ? SizedBox.shrink()
              : buildButton(context,
                  btnName: 'Cancel Match', onPressed: cancelMAtch),
        ],
      ),
    );
  }



  cancelMAtch() async {
    try {
      setState(() {
        isLoading= true;
      });
      matchRequestRepo
          .matchCancel(matchId: widget.opponentData.requestid!)
          .then((value) {
        if (value.isSuccess) {
          setState(() {
            isLoading= false;
          });
          showDialog(
                  context: context,
                  builder: (BuildContext context) =>
                      CancelMatch(widget.opponentData.requestid!))
              .whenComplete(() => Navigator.pop(context));
        } else {
          setState(() {
            isLoading= false;
          });
          MethodUtils.showSnackBarGK(_scaffoldKey, "${value.errorCause}");
        }
      });
    } catch (e) {
      setState(() {
        isLoading= false;
      });
      MethodUtils.showSnackBarGK(_scaffoldKey, e.toString());
    }
  }

  acceptMAtch() async {
    try {
      setState(() {
        isLoading= true;
      });
      matchRequestRepo
          .matchAccept(matchId: widget.opponentData.requestid!)
          .then((value) {
        if (value.isSuccess) {
          setState(() {
            isLoading= false;
          });
          showDialog(
                  context: context,
                  builder: (BuildContext context) =>
                      CancelMatch(widget.opponentData.requestid!,msg: "Accepted",))
              .whenComplete(() => Navigator.pop(context));
        } else {
          setState(() {
            isLoading= false;
          });
          MethodUtils.showSnackBarGK(_scaffoldKey, "${value.errorCause}");
        }
      });
    } catch (e) {
      setState(() {
        isLoading= false;
      });
      MethodUtils.showSnackBarGK(_scaffoldKey, e.toString());
    }
  }

  Column buildTopCounterCard({String? title, String? value}) {
    return Column(
      children: [
        DxText(
          title!,
          mSize: 18,
          mBold: true,
          textColor: Colors.grey,
        ),
        SizedBox(height: 8.0),
        DxTextBlack(
          value!,
          mSize: 18,
        ),
      ],
    );
  }

  Padding buildHeading(String? title) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: DxTextBlack(
        title!,
        mSize: 22,
        mBold: true,
      ),
    );
  }

  Padding buildBody({String? title, Color? color}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: DxTextBlack(
        title!,
        mBold: true,
        mSize: 18,
      ),
    );
  }

  Container buildButton(BuildContext context,
      {String? btnName, required void Function()? onPressed}) {
    return Container(
      // width: MediaQuery.of(context).size.width,
      padding: const EdgeInsets.symmetric(vertical: 20),
      child: Center(
        child: RaisedButton(
          elevation: 8.0,
          color: materialAccentColor,
          onPressed: onPressed,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 14),
            child: DxTextWhiteM(
              btnName!,
              mBold: true,
              mSize: 20,
            ),
          ),
        ),
      ),
    );
  }
}
