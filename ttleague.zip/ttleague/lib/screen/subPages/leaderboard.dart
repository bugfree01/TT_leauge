import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:tt_league/Model/MatchesModel.dart';
import 'package:tt_league/Model/leaderboard.dart';
import 'package:tt_league/Model/userModel.dart';
import 'package:tt_league/cubit/leaderboard/leaderboard_cubit.dart';
import 'package:tt_league/helper/app_utilities/appImages.dart';
import 'package:tt_league/helper/app_utilities/colors.dart';
import 'package:tt_league/helper/app_utilities/method_utils.dart';
import 'package:tt_league/helper/app_utilities/size_reziser.dart';
import 'package:tt_league/screen/customWidget/app_circular_loader.dart';
import 'package:tt_league/screen/customWidget/dxWidget/dx_text.dart';

class LeaderBoard extends StatefulWidget {
  @override
  _LeaderBoardState createState() => _LeaderBoardState();
}

class _LeaderBoardState extends State<LeaderBoard> {
  // Basic, Intermediate, Advanced, 60+ Intermediate, 60+ Advanced, Under 18, Under 15, Under 12
  List<String> categories = ["Advanced", "Intermediate", "Basic","60+ "
      "Intermediate","60+ Advanced","Under 18","Under 15","Under 12"];
  final _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: categories.length,
      child: Scaffold(
        key:_scaffoldKey ,
        // backgroundColor: materialPrimaryColor,
        appBar: AppBar(
          elevation: 0,
          leading: IconButton(
            onPressed: () {
              Navigator.pop(context);
            },
            icon: Icon(Icons.arrow_back_ios),
            color: Colors.grey,
            iconSize: 30,
          ),
          title: DxText(
            "Leaderboard",
            mSize: 35,
            mBold: true,
            textColor: Colors.white,
          ),
          backgroundColor: black_grey,
          // actions: <Widget>[
          //   Padding(
          //     padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          //     child: FloatingActionButton(
          //       backgroundColor: Colors.grey.shade600,
          //       foregroundColor: Colors.black,
          //       mini: true,
          //       onPressed: () {
          //
          //       },
          //       child: Icon(
          //         Icons.menu,
          //         color: Colors.white,
          //       ),
          //     ),
          //   )
          // ],
          bottom: TabBar(
              indicatorWeight: 1,
              isScrollable: true,
              labelColor: Colors.white,
              unselectedLabelStyle: TextStyle(fontSize: getSize(18, context)),
              // unselectedLabelColor: Colors.white10,
              indicatorSize: TabBarIndicatorSize.label,
              labelStyle: TextStyle(
                  fontWeight: FontWeight.w600, fontSize: getSize(20, context)),
              indicator: BoxDecoration(
                border: Border(
                  bottom: BorderSide(
                    color: Colors.white,
                  ),
                ),
              ),
              tabs: List.generate(
                  categories.length,
                      (index) =>
                      Container(
                          height: 38,
                          alignment: Alignment.centerLeft,
                          child: Text(categories[index])))),
        ),
        body: TabBarView(
          children: [
            Advanced(),
            Intermediate(),
            Basic(),
            IntermediateSixty(),
            AdvancedSixty(),
            Under18(),
            Under15(),
            Under12(),
          ],
        ),
      ),
    );
  }

}

class Advanced extends StatelessWidget {
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  late BuildContext c;

  @override
  Widget build(BuildContext context) {
    c = context;
    BlocProvider.of<LeaderboardCubit>(context).getplayersData("Advanced");
    return Scaffold(
      key: _scaffoldKey,
      body: grid(context),
    );
  }

  Widget grid(BuildContext context,{String category = "Advanced"}) {

    return BlocConsumer<LeaderboardCubit, LeaderboardState>(
        builder: (BuildContext context, state) {
          if (state is LeaderboardLoaded) {
            return body(state.players,category);
          }
          if (state is LeaderboardError) {
            return body([],category);
          }
          if (state is LeaderboardInitial) {
            return AppLoaderProgress();
          }

          return Container();
        }, listener: (BuildContext context, state) {

      if (state is LeaderboardError) {
        MethodUtils.showSnackBarGK(_scaffoldKey, "${state.error}");
      }
    });
  }

  Widget body(List<LeadrboardModel> players,String category) {
    return players.isEmpty ? Center(child: DxTextBlack("No Data Found!",
      mSize: 18,mBold: true,),) :
    Padding(
      padding: const EdgeInsets.only(bottom: 30),
      child: GridView.builder(
        padding: const EdgeInsets.all(8),
        itemCount: players.length,
        physics: ClampingScrollPhysics(),
        shrinkWrap: true,
        itemBuilder: (BuildContext context, index) {
          return gridBody(players[index]);
        },
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 5.0,
            crossAxisSpacing: 5.0,
            childAspectRatio: 6 / 8),
      ),
    );
  }

  Future<void> refreshList(String category)async {
    BlocProvider.of<LeaderboardCubit>(c).getplayersData(category);
  }

  Widget gridBody(LeadrboardModel playerData) {
    String image = playerData.playerimage!.split("/").last;
    return Stack(
      children: [
        Container(
          height: 300,
          width: 250,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: CachedNetworkImage(imageUrl:"http://www"
                ".sipconline.com/uat/sipl/images/$image",fit: BoxFit.cover,),
          ),
        ),
        Positioned(
            bottom: 10,
            left: 8,
            child: DxTextWhiteM(
              playerData.fullname!,
            )),
      ],
    );
  }

}

class Intermediate extends StatelessWidget {
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  late BuildContext c;

  @override
  Widget build(BuildContext context) {
    c = context;
    BlocProvider.of<LeaderboardCubit>(context).getplayersData("Intermediate");
    return Scaffold(
      key: _scaffoldKey,
      body: grid(context),
    );
  }

  Widget grid(BuildContext context,{String category = "Intermediate"}) {

    return BlocConsumer<LeaderboardCubit, LeaderboardState>(
        builder: (BuildContext context, state) {
          if (state is LeaderboardLoaded) {
            return body(state.players,category);
          }
          if (state is LeaderboardError) {
            return body([],category);
          }
          if (state is LeaderboardInitial) {
            return AppLoaderProgress();
          }

          return Container();
        }, listener: (BuildContext context, state) {

      if (state is LeaderboardError) {
        MethodUtils.showSnackBarGK(_scaffoldKey, "${state.error}");
      }
    });
  }

  Widget body(List<LeadrboardModel> players,String category) {
    return players.isEmpty ? Center(child: DxTextBlack("No Data Found!",
      mSize: 18,mBold: true,),) :
    Padding(
      padding: const EdgeInsets.only(bottom: 30),
      child: GridView.builder(
        padding: const EdgeInsets.all(8),
        itemCount: players.length,
        physics: ClampingScrollPhysics(),
        shrinkWrap: true,
        itemBuilder: (BuildContext context, index) {
          return gridBody(players[index]);
        },
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 5.0,
            crossAxisSpacing: 5.0,
            childAspectRatio: 6 / 8),
      ),
    );
  }

  Future<void> refreshList(String category)async {
    BlocProvider.of<LeaderboardCubit>(c).getplayersData(category);
  }

  Widget gridBody(LeadrboardModel playerData) {
    String image = playerData.playerimage!.split("/").last;
    return Stack(
      children: [
        Container(
          height: 300,
          width: 250,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: CachedNetworkImage(imageUrl:"http://www"
                ".sipconline.com/uat/sipl/images/$image",fit: BoxFit.cover,),
          ),
        ),
        Positioned(
            bottom: 10,
            left: 8,
            child: DxTextWhiteM(
              playerData.fullname!,
            )),
      ],
    );
  }

}

class Basic extends StatelessWidget {
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  late BuildContext c;

  @override
  Widget build(BuildContext context) {
    c = context;
    BlocProvider.of<LeaderboardCubit>(context).getplayersData("Basic");
    return Scaffold(
      key: _scaffoldKey,
      body: grid(context),
    );
  }

  Widget grid(BuildContext context,{String category = "Basic"}) {

    return BlocConsumer<LeaderboardCubit, LeaderboardState>(
        builder: (BuildContext context, state) {
          if (state is LeaderboardLoaded) {
            return body(state.players,category);
          }
          if (state is LeaderboardError) {
            return body([],category);
          }
          if (state is LeaderboardInitial) {
            return AppLoaderProgress();
          }

          return Container();
        }, listener: (BuildContext context, state) {

      if (state is LeaderboardError) {
        MethodUtils.showSnackBarGK(_scaffoldKey, "${state.error}");
      }
    });
  }

  Widget body(List<LeadrboardModel> players,String category) {
    return players.isEmpty ? Center(child: DxTextBlack("No Data Found!",
      mSize: 18,mBold: true,),) :
    Padding(
      padding: const EdgeInsets.only(bottom: 30),
      child: GridView.builder(
        padding: const EdgeInsets.all(8),
        itemCount: players.length,
        physics: ClampingScrollPhysics(),
        shrinkWrap: true,
        itemBuilder: (BuildContext context, index) {
          return gridBody(players[index]);
        },
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 5.0,
            crossAxisSpacing: 5.0,
            childAspectRatio: 6 / 8),
      ),
    );
  }

  Future<void> refreshList(String category)async {
    BlocProvider.of<LeaderboardCubit>(c).getplayersData(category);
  }

  Widget gridBody(LeadrboardModel playerData) {
    String image = playerData.playerimage!.split("/").last;
    return Stack(
      children: [
        Container(
          height: 300,
          width: 250,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: CachedNetworkImage(imageUrl:"http://www"
                ".sipconline.com/uat/sipl/images/$image",fit: BoxFit.cover,),
          ),
        ),
        Positioned(
            bottom: 10,
            left: 8,
            child: DxTextWhiteM(
              playerData.fullname!,
            )),
      ],
    );
  }

}

class IntermediateSixty extends StatelessWidget {
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  late BuildContext c;

  @override
  Widget build(BuildContext context) {
    c = context;
    BlocProvider.of<LeaderboardCubit>(context).getplayersData("60+ "
        "Intermediate");
    return Scaffold(
      key: _scaffoldKey,
      body: grid(context),
    );
  }

  Widget grid(BuildContext context,{String category = "60+ "
      "Intermediate"}) {

    return BlocConsumer<LeaderboardCubit, LeaderboardState>(
        builder: (BuildContext context, state) {
          if (state is LeaderboardLoaded) {
            return body(state.players,category);
          }
          if (state is LeaderboardError) {
            return body([],category);
          }
          if (state is LeaderboardInitial) {
            return AppLoaderProgress();
          }

          return Container();
        }, listener: (BuildContext context, state) {

      if (state is LeaderboardError) {
        MethodUtils.showSnackBarGK(_scaffoldKey, "${state.error}");
      }
    });
  }

  Widget body(List<LeadrboardModel> players,String category) {
    return players.isEmpty ? Center(child: DxTextBlack("No Data Found!",
      mSize: 18,mBold: true,),) :
    Padding(
      padding: const EdgeInsets.only(bottom: 30),
      child: GridView.builder(
        padding: const EdgeInsets.all(8),
        itemCount: players.length,
        physics: ClampingScrollPhysics(),
        shrinkWrap: true,
        itemBuilder: (BuildContext context, index) {
          return gridBody(players[index]);
        },
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 5.0,
            crossAxisSpacing: 5.0,
            childAspectRatio: 6 / 8),
      ),
    );
  }

  Future<void> refreshList(String category)async {
    BlocProvider.of<LeaderboardCubit>(c).getplayersData(category);
  }

  Widget gridBody(LeadrboardModel playerData) {
    String image = playerData.playerimage!.split("/").last;
    return Stack(
      children: [
        Container(
          height: 300,
          width: 250,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: CachedNetworkImage(imageUrl:"http://www"
                ".sipconline.com/uat/sipl/images/$image",fit: BoxFit.cover,),
          ),
        ),
        Positioned(
            bottom: 10,
            left: 8,
            child: DxTextWhiteM(
              playerData.fullname!,
            )),
      ],
    );
  }

}

class AdvancedSixty extends StatelessWidget {
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  late BuildContext c;

  @override
  Widget build(BuildContext context) {
    c = context;
    BlocProvider.of<LeaderboardCubit>(context).getplayersData("60+ Advanced");
    return Scaffold(
      key: _scaffoldKey,
      body: grid(context),
    );
  }

  Widget grid(BuildContext context,{String category = "60+ Advanced"}) {

    return BlocConsumer<LeaderboardCubit, LeaderboardState>(
        builder: (BuildContext context, state) {
          if (state is LeaderboardLoaded) {
            return body(state.players,category);
          }
          if (state is LeaderboardError) {
            return body([],category);
          }
          if (state is LeaderboardInitial) {
            return AppLoaderProgress();
          }

          return Container();
        }, listener: (BuildContext context, state) {

      if (state is LeaderboardError) {
        MethodUtils.showSnackBarGK(_scaffoldKey, "${state.error}");
      }
    });
  }

  Widget body(List<LeadrboardModel> players,String category) {
    return players.isEmpty ? Center(child: DxTextBlack("No Data Found!",
      mSize: 18,mBold: true,),) :
    Padding(
      padding: const EdgeInsets.only(bottom: 30),
      child: GridView.builder(
        padding: const EdgeInsets.all(8),
        itemCount: players.length,
        physics: ClampingScrollPhysics(),
        shrinkWrap: true,
        itemBuilder: (BuildContext context, index) {
          return gridBody(players[index]);
        },
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 5.0,
            crossAxisSpacing: 5.0,
            childAspectRatio: 6 / 8),
      ),
    );
  }

  Future<void> refreshList(String category)async {
    BlocProvider.of<LeaderboardCubit>(c).getplayersData(category);
  }

  Widget gridBody(LeadrboardModel playerData) {
    String image = playerData.playerimage!.split("/").last;
    return Stack(
      children: [
        Container(
          height: 300,
          width: 250,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: CachedNetworkImage(imageUrl:"http://www"
                ".sipconline.com/uat/sipl/images/$image",fit: BoxFit.cover,),
          ),
        ),
        Positioned(
            bottom: 10,
            left: 8,
            child: DxTextWhiteM(
              playerData.fullname!,
            )),
      ],
    );
  }

}

class Under18 extends StatelessWidget {
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  late BuildContext c;

  @override
  Widget build(BuildContext context) {
    c = context;
    BlocProvider.of<LeaderboardCubit>(context).getplayersData("Under 18");
    return Scaffold(
      key: _scaffoldKey,
      body: grid(context),
    );
  }

  Widget grid(BuildContext context,{String category = "Under 18"}) {

    return BlocConsumer<LeaderboardCubit, LeaderboardState>(
        builder: (BuildContext context, state) {
          if (state is LeaderboardLoaded) {
            return body(state.players,category);
          }
          if (state is LeaderboardError) {
            return body([],category);
          }
          if (state is LeaderboardInitial) {
            return AppLoaderProgress();
          }

          return Container();
        }, listener: (BuildContext context, state) {

      if (state is LeaderboardError) {
        MethodUtils.showSnackBarGK(_scaffoldKey, "${state.error}");
      }
    });
  }

  Widget body(List<LeadrboardModel> players,String category) {
    return players.isEmpty ? Center(child: DxTextBlack("No Data Found!",
      mSize: 18,mBold: true,),) :
    Padding(
      padding: const EdgeInsets.only(bottom: 30),
      child: GridView.builder(
        padding: const EdgeInsets.all(8),
        itemCount: players.length,
        physics: ClampingScrollPhysics(),
        shrinkWrap: true,
        itemBuilder: (BuildContext context, index) {
          return gridBody(players[index]);
        },
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 5.0,
            crossAxisSpacing: 5.0,
            childAspectRatio: 6 / 8),
      ),
    );
  }

  Future<void> refreshList(String category)async {
    BlocProvider.of<LeaderboardCubit>(c).getplayersData(category);
  }

  Widget gridBody(LeadrboardModel playerData) {
    String image = playerData.playerimage!.split("/").last;
    return Stack(
      children: [
        Container(
          height: 300,
          width: 250,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: CachedNetworkImage(imageUrl:"http://www"
                ".sipconline.com/uat/sipl/images/$image",fit: BoxFit.cover,),
          ),
        ),
        Positioned(
            bottom: 10,
            left: 8,
            child: DxTextWhiteM(
              playerData.fullname!,
            )),
      ],
    );
  }

}

class Under15 extends StatelessWidget {
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  late BuildContext c;

  @override
  Widget build(BuildContext context) {
    c = context;
    BlocProvider.of<LeaderboardCubit>(context).getplayersData("Under 15");
    return Scaffold(
      key: _scaffoldKey,
      body: grid(context),
    );
  }

  Widget grid(BuildContext context,{String category = "Under 15"}) {

    return BlocConsumer<LeaderboardCubit, LeaderboardState>(
        builder: (BuildContext context, state) {
          if (state is LeaderboardLoaded) {
            return body(state.players,category);
          }
          if (state is LeaderboardError) {
            return body([],category);
          }
          if (state is LeaderboardInitial) {
            return AppLoaderProgress();
          }

          return Container();
        }, listener: (BuildContext context, state) {

      if (state is LeaderboardError) {
        MethodUtils.showSnackBarGK(_scaffoldKey, "${state.error}");
      }
    });
  }

  Widget body(List<LeadrboardModel> players,String category) {
    return players.isEmpty ? Center(child: DxTextBlack("No Data Found!",
      mSize: 18,mBold: true,),) :
    Padding(
      padding: const EdgeInsets.only(bottom: 30),
      child: GridView.builder(
        padding: const EdgeInsets.all(8),
        itemCount: players.length,
        physics: ClampingScrollPhysics(),
        shrinkWrap: true,
        itemBuilder: (BuildContext context, index) {
          return gridBody(players[index]);
        },
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 5.0,
            crossAxisSpacing: 5.0,
            childAspectRatio: 6 / 8),
      ),
    );
  }

  Future<void> refreshList(String category)async {
    BlocProvider.of<LeaderboardCubit>(c).getplayersData(category);
  }

  Widget gridBody(LeadrboardModel playerData) {
    String image = playerData.playerimage!.split("/").last;
    return Stack(
      children: [
        Container(
          height: 300,
          width: 250,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: CachedNetworkImage(imageUrl:"http://www"
                ".sipconline.com/uat/sipl/images/$image",fit: BoxFit.cover,),
          ),
        ),
        Positioned(
            bottom: 10,
            left: 8,
            child: DxTextWhiteM(
              playerData.fullname!,
            )),
      ],
    );
  }

}

class Under12 extends StatelessWidget {
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  late BuildContext c;

  @override
  Widget build(BuildContext context) {
    c = context;
    BlocProvider.of<LeaderboardCubit>(context).getplayersData("Under 12");
    return Scaffold(
      key: _scaffoldKey,
      body: grid(context),
    );
  }

  Widget grid(BuildContext context,{String category = "Under 12"}) {

    return BlocConsumer<LeaderboardCubit, LeaderboardState>(
        builder: (BuildContext context, state) {
          if (state is LeaderboardLoaded) {
            return body(state.players,category);
          }
          if (state is LeaderboardError) {
            return body([],category);
          }
          if (state is LeaderboardInitial) {
            return AppLoaderProgress();
          }

          return Container();
        }, listener: (BuildContext context, state) {

      if (state is LeaderboardError) {
        MethodUtils.showSnackBarGK(_scaffoldKey, "${state.error}");
      }
    });
  }

  Widget body(List<LeadrboardModel> players,String category) {
    return players.isEmpty ? Center(child: DxTextBlack("No Data Found!",
      mSize: 18,mBold: true,),) :
    Padding(
      padding: const EdgeInsets.only(bottom: 30),
      child: GridView.builder(
        padding: const EdgeInsets.all(8),
        itemCount: players.length,
        physics: ClampingScrollPhysics(),
        shrinkWrap: true,
        itemBuilder: (BuildContext context, index) {
          return gridBody(players[index]);
        },
        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 5.0,
            crossAxisSpacing: 5.0,
            childAspectRatio: 6 / 8),
      ),
    );
  }

  Future<void> refreshList(String category)async {
    BlocProvider.of<LeaderboardCubit>(c).getplayersData(category);
  }

  Widget gridBody(LeadrboardModel playerData) {
    String image = playerData.playerimage!.split("/").last;
    return Stack(
      children: [
        Container(
          height: 300,
          width: 250,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: CachedNetworkImage(imageUrl:"http://www"
                ".sipconline.com/uat/sipl/images/$image",fit: BoxFit.cover,),
          ),
        ),
        Positioned(
            bottom: 10,
            left: 8,
            child: DxTextWhiteM(
              playerData.fullname!,
            )),
      ],
    );
  }

}
