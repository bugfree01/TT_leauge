import 'dart:async';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:tt_league/helper/app_utilities/colors.dart';
import 'package:tt_league/screen/customWidget/dxWidget/dx_text.dart';
import 'package:webview_flutter/webview_flutter.dart';

class WebviewPage extends StatefulWidget {
  String url;
  String appBarName;

  WebviewPage({required this.url,  required this.appBarName});

  @override
  _WebviewPageState createState() => _WebviewPageState(url);
}

class _WebviewPageState extends State<WebviewPage> {
  String url = "";
  String appBarName = "";

  _WebviewPageState(this.url);

  final _scaffoldKey = GlobalKey<ScaffoldState>();
  final Completer<WebViewController> _controller = Completer<WebViewController>();
  WebViewController? _wwController;

  @override
  void initState() {
    if (Platform.isAndroid) WebView.platform = SurfaceAndroidWebView();
  }


  Future<bool> popWebview() async {
    if (_wwController == null) {
      return Future.value(true);
    } else {
      if (await _wwController!.canGoBack()) {
        await _wwController!.goBack();
        return Future.value(false);
      } else {
        return Future.value(true);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    print("your url is $url");
    return WillPopScope(
      onWillPop: popWebview,
      child: Scaffold(
          key: _scaffoldKey,
          appBar: AppBar(
            leading: IconButton( onPressed: () async {
              popWebview().then((value) {
                if (value) {
                  Navigator.pop(context);
                }
              });
            }, icon: Icon(Icons.arrow_back),
            ),
            backgroundColor: black_grey,
            title: DxTextWhite(widget.appBarName,mSize: 18,mBold: true,),
          ),
          body: WebView(
            // initialUrl:
            initialUrl: url,
            onPageFinished: (url) {},
            onWebViewCreated: (WebViewController webViewController) {
              _wwController = webViewController;
              _controller.complete(webViewController);
            },
          )),
    );
    // return web(url);
  }
}
