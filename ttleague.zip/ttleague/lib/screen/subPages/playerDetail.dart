import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:tt_league/Model/userModel.dart';
import 'package:tt_league/cubit/home/home_cubit.dart';
import 'package:tt_league/helper/app_utilities/appImages.dart';
import 'package:tt_league/helper/app_utilities/app_theme.dart';
import 'package:tt_league/screen/customWidget/bannerWidget/imageSlider.dart';
import 'package:tt_league/screen/customWidget/dailog/matchRequest.dart';
import 'package:tt_league/screen/customWidget/dxWidget/dx_text.dart';

class PlayerDetails extends StatefulWidget {
  UserModel userModel;

  PlayerDetails({required this.userModel});

  @override
  _PlayerDetailsState createState() => _PlayerDetailsState();
}

class _PlayerDetailsState extends State<PlayerDetails> {
  int _currentIndex = 0;
  int maxLine = 2;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildTopBanner(context,),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  flex: 1,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      buildHeading(widget.userModel.fullname),
                      buildBody(title:widget.userModel.location , color: Colors.grey),
                    ],
                  ),
                ),

                widget.userModel.age!.isNotEmpty? GradientColor(widget
                    .userModel.age,
                  true,showButton: true,width:
                80,):SizedBox.shrink()

              ],
            ),
            SizedBox(height:20),
            Container(
              margin: EdgeInsets.symmetric(horizontal: 8.0),
              padding: const EdgeInsets.symmetric(vertical: 15.0),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8.0),
                  color: Color(0xffEFEFEF),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0xff000000).withOpacity(0.2),
                      blurRadius: 5.0,
                    ),
                  ]),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  GradientColor(widget.userModel.playerlevel, false,),
                  // GradientColor("${widget.userModel.credits} Credits",
                  //     false,),
                  GradientColor( "${widget.userModel.earnedCredits} Earned",
                    false),

                ],
              ),
            ),
            widget.userModel.description!.isNotEmpty? buildHeading('About')
                :SizedBox.shrink(),
            widget.userModel.description!.isNotEmpty?  buildBody(
                title: widget.userModel.description,
                color: Colors.black):SizedBox.shrink(),
            SizedBox(height: 16),
            widget.userModel.description!.isNotEmpty?  InkWell(
              onTap: () => setState((){
                showText = !showText;
                maxLine == 2 ? 4:2;
              }),
              child: buildBody(
                  title: !showText ? 'Show more' : 'Show less',
                  color: Theme.of(context).accentColor),
            ):SizedBox.shrink(),
            SizedBox(height: 20),
            buildHeading('Career Statistics'),
            Row(children: [
              buildBody(title: 'Matches:', color: Colors.black),
              buildBody(title: widget.userModel.matches.toString(), color: Colors.grey),
            ]),
            Row(children: [
              buildBody(title: 'Wins:', color: Colors.black),
              buildBody(title: widget.userModel.wins.toString(), color: Colors
                  .grey),
            ]),
            Row(children: [
              buildBody(title: 'Winning:', color: Colors.black),
              buildBody(title: '${widget.userModel.percentage}%', color: Colors.grey),
            ]),

            SizedBox(height: 30),
            Row(children: [
              buildBody(title: 'Preferred Location', color: Colors.black),
              buildBody(title: widget.userModel.preflocation, color: Colors.black),
            ],),

            Divider(height: 30),
            Row(children: [
              buildBody(title: 'Preferred Time', color: Colors.black),
              buildBody(title: widget.userModel.preftime, color: Colors.black),

            ],),

            Divider(height: 30),
            buildRequestButton(context),
          ],
        ),
      ),
    );
  }

  bool showText = false;

  // String? text =
  //     "My name is Ma Long and I enjoy meeting new people and finding ways to help them have an uplifting experience. I enjoy reading, and the knowledge.";
  //
  // List<String> chipName = [
  //   "Guitar",
  //   "Music",
  //   "Fishing",
  //   "Swimming",
  //   "Book",
  //   "Dancing"
  // ];
  //
  // _buildChoiceList() {
  //   List<Widget> choices = <Widget>[];
  //   chipName.forEach((item) {
  //     choices.add(Container(
  //       margin: const EdgeInsets.all(8.0),
  //       child: Chip(
  //         shape: RoundedRectangleBorder(
  //           borderRadius: BorderRadius.circular(8.0),
  //           side: BorderSide(
  //             width: 1,
  //             color: Color(0xffDAD9E2),
  //           ),
  //         ),
  //         label: Padding(
  //           padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
  //           child: Text(item),
  //         ),
  //         labelStyle: TextStyle(color: Colors.black),
  //         // selectedColor: Colors.pinkAccent,
  //         backgroundColor: Colors.white,
  //         // selected: _isSelected == item,
  //         // onSelected: (selected) {
  //         //   setState(() {
  //         //     _isSelected = item;
  //         //   });
  //         // },
  //       ),
  //     ));
  //   });
  //   return choices;
  // }

  Padding buildHeading(String? title) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: DxTextBlack(
        title!,
        mSize: 22,
        mBold: true,
      ),
    );
  }

  Padding buildBody({String? title, Color? color,bool bold = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: DxText(
        title!,
        mSize: 18,
        mBold: bold,
        textColor: color!,
      ),
    );
  }

  Stack _buildTopBanner(BuildContext context, ) {
    String image = widget.userModel.image1.split("/").last;
    return Stack(
      children: [
        // CarouselSlider(
        //   options: CarouselOptions(
        //     height: MediaQuery.of(context).size.height / 1.5,
        //     // height: 180.0,
        //     // autoPlay: true,
        //     autoPlayInterval: Duration(seconds: 3),
        //     autoPlayAnimationDuration: Duration(milliseconds: 800),
        //     autoPlayCurve: Curves.fastOutSlowIn,
        //     pauseAutoPlayOnTouch: true,
        //     aspectRatio: 2.0,
        //     viewportFraction: 1.0,
        //     onPageChanged: (index, reason) {
        //       setState(() {
        //         _currentIndex = index;
        //       });
        //     },
        //   ),
        //   items: imagesList!.map((item) {
        //     return Builder(
        //       builder: (BuildContext context) {
        //         return Container(
        //           // margin: const EdgeInsets.symmetric(horizontal: 4),
        //           height: MediaQuery.of(context).size.height * 0.30,
        //           width: MediaQuery.of(context).size.width,
        //           child: Container(
        //             height: 180,
        //             width: double.infinity,
        //             child: Image.asset(
        //               item.image!,
        //               fit: BoxFit.cover,
        //             ),
        //           ),
        //         );
        //       },
        //     );
        //   }).toList(),
        // ),
        Container(
          height: 450,
          width: double.infinity,
          child: CachedNetworkImage(
            imageUrl:"http://www.sipconline.com/uat/sipl/images/$image",
            placeholder: (context, url) => Container(
              transform: Matrix4.translationValues(0.0, 0.0, 0.0),
              child: Container(
                  width: double.infinity,
                  height: MediaQuery.of(context).size.height*0.77,
                  child: Center(child: new CircularProgressIndicator())),
            ),
            errorWidget: (context, url, error) => new Icon(Icons.error),
            fit: BoxFit.cover,
          ),
          // child: ImageSliderWidget(
          //     imageHeight: 450,
          //     imagePadding: 0,
          //     allbanner: dummyImages,
          //     imageBorderRadius: BorderRadius.circular(10)),
        ),
        Container(color: Colors.red,),
        // Positioned(
        //   top: 56,
        //   right: 0,
        //   child: Column(
        //     children: imagesList!.map(
        //           (image) {
        //         int index = imagesList.indexOf(image);
        //         return Container(
        //           width: 10.0,
        //           height: 10.0,
        //           margin: EdgeInsets.symmetric(vertical: 4.0, horizontal: 12.0),
        //           decoration: BoxDecoration(
        //               shape: BoxShape.circle,
        //               color:
        //               _currentIndex == index ? Colors.white : Colors.grey),
        //         );
        //       },
        //     ).toList(),
        //   ),
        // ),
        Positioned(
          top: 40.0,
          child: IconButton(
            onPressed: () => Navigator.pop(context),
            icon: Icon(
              Icons.cancel,
              size: 40.0,
            ),
            color: Colors.white,
          ),
        ),
        Positioned(
          top: 48.0,
          right: 40.0,
          child: CircleAvatar(
            radius: 28,
            backgroundColor: Colors.white,
            // backgroundImage: AssetImage(AppImages.heartIcon1),
            child: Padding(
              padding: const EdgeInsets.all(12.0),
              child: Image.asset(AppImages.heartIcon1),
            ),
            // child: Center(
            //   child: Icon(
            //     Icons.favorite,
            //     color: Colors.red,
            //     size: 40,
            //   ),
            // ),
          ),
        ),
      ],
    );
  }

  Container buildRequestButton(BuildContext context) {
    return Container(
      // width: MediaQuery.of(context).size.width - 150,
      padding: const EdgeInsets.symmetric(vertical: 40),
      child: Center(
        child: RaisedButton(
          elevation: 8.0,
          onPressed: () {
            BlocProvider.of<HomeCubit>(context).matchRequest(widget.userModel
                .userid!,context);
          },
          color: materialAccentColor,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 14),
            child: DxTextWhiteM(
              'Request Match',
              mBold: true,
             mSize: 20,
            ),
          ),
        ),
      ),
    );
  }
}

class DummyImages {
  String? image;

  DummyImages({this.image});
}

List<String> dummyImages = [
   AppImages.player2,
   AppImages.player3,
  AppImages.player4,
  AppImages.player1,
];

class GradientColor extends StatelessWidget {
  String? image;
  String? data;
  bool showImage = true;
  bool showButton = false;
  double width = 80;

  GradientColor(this.data, this.showImage,{this.showButton =
  false,this.width=80});

  @override
  Widget build(BuildContext context) {
    return  Container(
      margin: EdgeInsets.only(top: 20),
      padding: EdgeInsets.symmetric(vertical: 8, horizontal: 6),
      alignment: Alignment.center,
      width:showButton? width:null,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          stops: [0.1, 0.5, 0.7, 0.9],
          colors: [
            Color(0xffFF8960),
            Color(0xffFF8960),
            Color(0xffFF689A),
            Color(0xffFF689A),
          ],
        ),
      ),
      child: DxTextWhiteM(
        data!,
        mSize: 17,
        mBold: true,
      ),
    );
  }
}
