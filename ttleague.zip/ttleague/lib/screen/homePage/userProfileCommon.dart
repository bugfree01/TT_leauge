// import 'package:datingappmain/commons/constData.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:tt_league/Model/userModel.dart';
import 'package:tt_league/cubit/home/home_cubit.dart';
import 'package:tt_league/helper/app_utilities/appImages.dart';
import 'package:tt_league/helper/app_utilities/app_theme.dart';
import 'package:tt_league/screen/customWidget/dxWidget/dx_text.dart';
import 'package:tt_league/screen/homePage/tinderAnimation.dart';
import 'package:tt_league/screen/subPages/playerDetail.dart';

mixin userProfileCommon {
  CardController cardController = CardController();
   // late BuildContext context;
   // late UserModel userModel;

  Widget userInformation(UserModel userData, Size size, BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.only(bottom: 2),
                width: 200,
                child: DxTextWhite(
                  userData.fullname!,
                  mSize: 20,
                  mBold: true,
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(left: 8.0),
                child: DxTextWhite(
                  userData.age!,
                  mSize: 18,
                  mBold: true,
                ),
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(bottom: 8.0, right: 12),
            child: Container(
              width: size.width - 20,
              child: DxTextWhite(
                userData.location!,
              ),
            ),
          ),
          interestingWidget(userData.playerlevel!),

          // Wrap(children: userData.interesting.map(interestingWidget).toList(),),
        ],
      ),
    );
  }

  Widget interestingWidget(String interesting) {
    return Padding(
      padding: const EdgeInsets.only(right: 8.0, bottom: 4.0),
      child: Container(
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10), color: Colors.grey[700]),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(6, 4, 6, 4),
          child: DxTextWhite(
            interesting,
          ),
        ),
      ),
    );
  }


  Widget bottomButtonWidget(BottomButtonData data,BuildContext context,UserModel userModel) {
    return Flexible(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 0),
        child: new RawMaterialButton(
          onPressed: () {
            if (data.iconData == AppImages.checkIcon) {
              cardController.triggerRight();
              BlocProvider.of<HomeCubit>(context)
                  .matchRequest(userModel.userid!, context);

            } else if (data.iconData == AppImages.removeIcon) {
              cardController.triggerLeft();
              //call cancel api
            } else if (data.iconData == AppImages.infoIcon) {
              // cardController.triggerUp();
              Navigator.push(context, MaterialPageRoute(builder: (context)
              =>PlayerDetails(userModel: userModel,)));
            }
          },
          child: new Image.asset(
            data.iconData,
            color: data.iconColor == null ? null : data.iconColor,
            height: 20,
          ),
          shape: new CircleBorder(),
          elevation: 1.0,
          fillColor: Colors.white,
          padding: const EdgeInsets.all(14.0),
        ),
      ),
    );
  }
}

class BottomButtonWidget extends StatefulWidget {

  @override
  _BottomButtonWidgetState createState() => _BottomButtonWidgetState();
}

class _BottomButtonWidgetState extends State<BottomButtonWidget> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
