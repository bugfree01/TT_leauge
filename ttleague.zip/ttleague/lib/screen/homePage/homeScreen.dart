import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:scrolling_page_indicator/scrolling_page_indicator.dart';
import 'package:tt_league/Model/userModel.dart';
import 'package:tt_league/cubit/home/home_cubit.dart';
import 'package:tt_league/helper/app_utilities/appImages.dart';
import 'package:tt_league/helper/app_utilities/app_theme.dart';
import 'package:tt_league/helper/app_utilities/device_info.dart';
import 'package:tt_league/helper/app_utilities/method_utils.dart';
import 'package:tt_league/helper/app_utilities/size_reziser.dart';
import 'package:tt_league/helper/routeAndBlocManager/navigator.dart';
import 'package:tt_league/screen/customWidget/app_circular_loader.dart';
import 'package:tt_league/screen/homePage/tinderAnimation.dart';
import 'package:tt_league/screen/homePage/userProfileCommon.dart';
import 'package:tt_league/screen/subPages/leaderboard.dart';
import 'package:tt_league/screen/subPages/playerDetail.dart';
import 'package:tt_league/screen/subPages/webScreen.dart';
import '../../helper/app_utilities/colors.dart';
import '../customWidget/dxWidget/dx_text.dart';

class Constants {
  static const String venue = 'Venues';
  static const String tournament = 'Tournaments';
  static const String leaderboard = 'Leaderboards';

  static const List<String> choices = <String>[venue, tournament, leaderboard];
}

class HomeScreen extends StatefulWidget {
  static const routeName = 'home-screen';

  const HomeScreen({Key? key}) : super(key: key);

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    BlocProvider.of<HomeCubit>(context).getPlayers();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
        key: _scaffoldKey,
        backgroundColor: materialPrimaryColor,
        appBar: AppBar(
          elevation: 0,
          automaticallyImplyLeading: false,
          title: DxText(
            "Players",
            mSize: 35,
            mBold: true,
            textColor: Colors.white,
          ),
          backgroundColor: black_grey,
          actions: <Widget>[
            // Padding(
            //   padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            //   child: FloatingActionButton(
            //     backgroundColor: Colors.grey.shade600,
            //     foregroundColor: Colors.black,
            //     mini: true,
            //     onPressed: () {
            //       openScreenAsBottomToTop(context, LeaderBoard());
            //     },
            //     child: Icon(
            //       Icons.menu,
            //       color: Colors.white,
            //     ),
            //   ),
            // )
            PopupMenuButton<String>(
              onSelected: choiceAction,
              itemBuilder: (BuildContext context) {
                return Constants.choices.map((String choice) {
                  return PopupMenuItem<String>(
                    value: choice,
                    child: Text(choice),
                  );
                }).toList();
              },
            )
          ],
        ),
        body: BlocConsumer<HomeCubit, HomeState>(
            builder: (BuildContext context, state) {
          if (state is HomeLoaded) {
            return HomePageBody(state.players);
          }
          if (state is HomeError) {
            return HomePageBody([]);
          }
          if (state is HomeInitial) {
            return AppLoaderProgress();
          }

          return Container();
        }, listener: (BuildContext context, state) {
          if (state is HomeError) {
            MethodUtils.showSnackBarGK(_scaffoldKey, "${state.error}");
          }
        }));
  }

  void choiceAction(String choice) {
    if (choice == Constants.leaderboard) {
      openScreenAsBottomToTop(context, LeaderBoard());
      print('Settings');
    } else if (choice == Constants.venue) {

      openScreenAsBottomToTop(context, WebviewPage(url: 'https://www.ttleague.sg/venues.php',appBarName: "Venue"
        ,));
      print('Subscribe');
    } else if (choice == Constants.tournament) {
      openScreenAsBottomToTop(context, WebviewPage(url: 'https://www.ttleague.sg/tournaments/tournaments.php',appBarName: "Tourn"
          "ament"
        ,));
      print('SignOut');
    }
  }
}

class HomePageBody extends StatefulWidget {
  List<UserModel> players;

  HomePageBody(this.players);

  @override
  State<StatefulWidget> createState() => _HomePageBody();
}

class _HomePageBody extends State<HomePageBody>
    with
        userProfileCommon,
        WidgetsBindingObserver,
        AutomaticKeepAliveClientMixin<HomePageBody> {
  @override
  bool get wantKeepAlive => true;
  bool? _isLike;
  int _currentIndex = 0;
  double _xPosition = 0.0;
  late PageController _pageController;
  late bool smallDevices;
  late bool LargeDevices;
  late bool tabDevices;
  late double maxHeight;
  late double infoPaddingHeight;
  late double maxWidth;
  late int listLength = widget.players.length;
  late BuildContext c;

  @override
  Widget build(BuildContext context) {
    c = context;
    print("youe data is ${widget.players.length}");
    print("youe data is ${widget.players.length}");
    smallDevices = DeviceInfo.useLayoutExtraSmall(context);
    LargeDevices = DeviceInfo.useLayoutMiddle(context);
    tabDevices = DeviceInfo.useMobileLayout(context);
    SizeConfig().init(context);
    final size = MediaQuery.of(context).size;
    maxHeight = MediaQuery.of(context).size.height * 0.85;
    final height = MediaQuery.of(context).size.height * 0.7;
    infoPaddingHeight = SizeConfig.safeBlockVertical * 4;
    final width = MediaQuery.of(context).size.width * 0.84;
    maxWidth = MediaQuery.of(context).size.width;
    return widget.players.isEmpty
        ? Center(
            child: DxTextWhite(
              "No Data "
              "Found",
              mBold: true,
              mSize: 18,
            ),
          )
        : Stack(
            children: <Widget>[
              TinderSwapCardAnimation(
                orientation: AmassOrientation.bottom,
                totalNum: widget.players.length,
                stackNum: 3,
                swipeEdge: 4.0,
                maxWidth: maxWidth,
                maxHeight: maxHeight,
                minWidth: width,
                minHeight: height,
                cardController: cardController,
                cardBuilder: (context, index) {
                  return Stack(
                    children: <Widget>[
                      PageView(
                        controller: _pageController =
                            PageController(initialPage: 0),
                        children:
                            _userProfile(size, index, widget.players[index]),
                        scrollDirection: Axis.vertical,
                      ),
                      Positioned(
                        top: 54,
                        right: 36,
                        child: _isLike != null &&
                                !_isLike! &&
                                index == _currentIndex
                            ? _likeOrDislikeIconOnPhoto(
                                FontAwesomeIcons.ban, Colors.redAccent)
                            : Container(),
                      ),
                      Positioned(
                        top: 50,
                        left: 40,
                        child: _isLike != null &&
                                _isLike! &&
                                index == _currentIndex
                            ? _likeOrDislikeIconOnPhoto(
                                FontAwesomeIcons.smile, Colors.green.shade800)
                            : Container(),
                      )
                    ],
                  );
                },
                swipeUpdateCallback:
                    (DragUpdateDetails details, Alignment align) {
                  if (align.x < 0) {
                    //Card is LEFT swiping
                    if (align.x < -3) {
                      _isLike = false;
                    }
                    if (-(align.x * 0.1) > 1) {
                      _xPosition = 1;
                    } else {
                      _xPosition = -(align.x * 0.1);
                    }
                  } else if (align.x > 0) {
                    //Card is RIGHT swiping
                    if (align.x > 3) {
                      _isLike = true;
                    }
                    if ((align.x * 0.1) > 1) {
                      _xPosition = 1;
                    } else {
                      _xPosition = (align.x * 0.1);
                      print("dfg");
                    }
                  } else {
                    _xPosition = 0;
                  }
                },
                swipeCompleteCallback:
                    (CardSwipeOrientation orientation, int index) {
                  print('orientation is $orientation and index is $index');
                  if (orientation == CardSwipeOrientation.left ||
                      orientation == CardSwipeOrientation.right) {
                    setState(() {
                      _currentIndex = index + 1;
                    });

                    _pageController.jumpToPage(0);
                  }
                  if (orientation == CardSwipeOrientation.right) {
                    BlocProvider.of<HomeCubit>(context)
                        .matchRequest(widget.players[index].userid!, context);
                  }
                  if (index >= listLength - 1) {
                    BlocProvider.of<HomeCubit>(context).getPlayers();
                  }
                  _isLike = null;
                },
              ),
              Padding(
                // bottom: 0,
                padding: EdgeInsets.only(top: height - 2),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  // children: bottomIconDataList.map(bottomButtonWidget).toList(),
                  children: List.generate(bottomIconDataList.length, (i) {
                    UserModel u = widget.players[_currentIndex];
                    return bottomButtonWidget(bottomIconDataList[i], c,
                        widget.players[_currentIndex]);
                  }),
                ),
              ),
            ],
          );
  }

  Widget _likeOrDislikeIconOnPhoto(IconData icon, Color iconColor) {
    return AnimatedOpacity(
      opacity: _xPosition,
      duration: Duration(milliseconds: 500),
      child: Stack(
        children: <Widget>[
          Positioned(
              left: 1.0,
              top: 2.0,
              child: FaIcon(
                icon,
                color: Colors.black54,
                size: 76,
              )),
          FaIcon(
            icon,
            color: iconColor,
            size: 76,
          )
        ],
      ),
    );
  }

  List<Widget> _userProfile(Size size, int index, UserModel userModel) {
    String image = userModel.image1.split("/").last;
    List<Widget> _returnWidgetList = [];
    final height = SizeConfig.safeBlockHorizontal * 120;
    final height1 = size.height * 0.75;
    print("your scrool top position is${height}");
    // for (int i = 0;
    //     i < dummyUserDataListInSearch[index].userImages.length;
    //     i++) {
    Widget _userWidget = Stack(
      children: [
        Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8.0),
            color: Colors.white,
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(8.0),
            child: CachedNetworkImage(
              imageUrl: "http://www.sipconline.com/uat/sipl/images/$image",
              placeholder: (context, url) => Container(
                transform: Matrix4.translationValues(0.0, 0.0, 0.0),
                child: Container(
                    width: double.infinity,
                    height: MediaQuery.of(context).size.height * 0.77,
                    child: Center(child: new CircularProgressIndicator())),
              ),
              errorWidget: (context, url, error) => new Icon(Icons.error),
              width: double.infinity,
              height: MediaQuery.of(context).size.height * 0.77,
              fit: BoxFit.cover,
            ),
          ),
        ),
        Positioned(
            bottom: 80, left: 4, child: userInformation(userModel, size, c)),
        // Positioned(
        //   top: 10,
        //   // top: infoPaddingHeight,
        //   left: 5,
        //   child:  IconButton(onPressed: (){
        //     Navigator.push(context, MaterialPageRoute(builder: (context)
        //     =>PlayerDetails(userModel: userModel,)));
        //   }, icon:Icon(Icons.info_outline,color: Colors.white,)),
        // ),

        // Positioned(
        //   right: 20,
        //   top: scrollposition,
        //   child: ScrollingPageIndicator(
        //       dotColor: Colors.grey,
        //       dotSelectedColor: Colors.white,
        //       dotSize: 6,
        //       dotSelectedSize: 10,
        //       dotSpacing: 16,
        //       controller: _pageController,
        //       itemCount:
        //       dummyUserDataListInSearch[index].userImages.length,
        //       orientation: Axis.vertical),
        // ),
        // Positioned(
        //  bottom: 5,
        //   child: Row(
        //     mainAxisAlignment: MainAxisAlignment.center,
        //     children: bottomIconDataList.map(bottomButtonWidget).toList(),
        //   ),
        // ),
      ],
    );
    _returnWidgetList.add(_userWidget);
    // }
    return _returnWidgetList;
  }
}
