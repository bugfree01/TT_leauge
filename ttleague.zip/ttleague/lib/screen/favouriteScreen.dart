import 'package:flutter/material.dart';
import 'package:tt_league/Model/MatchesModel.dart';
import 'package:tt_league/helper/app_utilities/appImages.dart';
import 'package:tt_league/helper/app_utilities/colors.dart';
import 'package:tt_league/helper/routeAndBlocManager/navigator.dart';
import 'package:tt_league/screen/subPages/leaderboard.dart';
import 'customWidget/dxWidget/dx_text.dart';

class FavouriteScreen extends StatefulWidget {
  static const routeName = 'favourite-screen';
  const FavouriteScreen({Key? key}) : super(key: key);
  @override
  _FavouriteScreenState createState() => _FavouriteScreenState();

}

class _FavouriteScreenState extends State<FavouriteScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(120.0),
               child: Container(
                 color: black_grey,
                 child: Column(children: [
                   AppBar(
                     elevation: 0,
                     automaticallyImplyLeading: false,
                     title: DxText(
                       "Favourites",
                       mSize: 35,
                       mBold: true,
                       textColor: Colors.white,
                     ),
                     backgroundColor: black_grey,
                     actions: <Widget>[
                       Padding(
                         padding: const EdgeInsets.symmetric(horizontal: 12, vertical:10),
                         child: FloatingActionButton(
                           backgroundColor: Colors.grey.shade600,
                           foregroundColor: Colors.black,
                           mini: true,
                           onPressed: () {
                             openScreenAsBottomToTop(context,LeaderBoard());
                           },
                           child: Icon(
                             Icons.menu,
                             color: Colors.white,
                           ),
                         ),
                       )
                     ],
                   ),
                   Container(
                     height: 50,
                     decoration: BoxDecoration(
                       color: Color(0xffE6E6E6),
                       borderRadius: BorderRadius.circular(8),
                     ),
                     alignment: Alignment.center,
                     margin: EdgeInsets.symmetric(horizontal: 12),
                     padding: EdgeInsets.symmetric(horizontal: 8,),
                     child: DxTextBlack("All Connections")
                   )
                 ],),
               )
      ),
      body: grid(),
    );
  }
  Widget grid() {
    return GridView.builder(
      padding: const EdgeInsets.all(8),
      itemCount: matchesList.length,
      physics: ClampingScrollPhysics(),
      shrinkWrap: true,
      itemBuilder: (BuildContext context, index) {
        return gridBody(matchesList[index]);
      },
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 2.0,
          crossAxisSpacing: 3.0,
          childAspectRatio: 6 / 8),
    );
  }

  Widget gridBody(MatchModel matches) {
    return Stack(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Image.asset(matches.image),
        ),
        Positioned(
            bottom: 10,
            left: 8,
            child: DxTextWhiteM(
              matches.name,
            )),
      ],
    );
  }
  Widget gradientContainer(){
    return Container(
      width: 80,
      margin: EdgeInsets.only(top: 20),
      padding: EdgeInsets.symmetric(vertical: 8, horizontal: 4),
      alignment: Alignment.center,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          stops: [0.1, 0.5, 0.7, 0.9],
          colors: [
            Color(0xffFF8960),
            Color(0xffFF8960),
            Color(0xffFF689A),
            Color(0xffFF689A),
          ],
        ),
      ),
      child: Row(
        children: [
          Image.asset(AppImages.womanIcon, width: 20),
          SizedBox(width: 4.0),
          DxTextWhiteM(
            '400',
            mSize: 20,
            mBold: true,
          ),
        ],
      ),
    );
  }
}
