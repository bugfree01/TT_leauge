import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:tt_league/Model/MatchesModel.dart';
import 'package:tt_league/Model/matchRequestModel.dart';
import 'package:tt_league/cubit/matchRequest/match_request_cubit.dart';
import 'package:tt_league/helper/app_utilities/app_theme.dart';
import 'package:tt_league/helper/app_utilities/colors.dart';
import 'package:tt_league/helper/app_utilities/device_info.dart';
import 'package:tt_league/helper/app_utilities/method_utils.dart';
import 'package:tt_league/helper/app_utilities/size_reziser.dart';
import 'package:tt_league/helper/routeAndBlocManager/navigator.dart';
import 'package:tt_league/screen/subPages/MatchDetails.dart';
import 'package:tt_league/screen/subPages/leaderboard.dart';

import 'customWidget/app_circular_loader.dart';
import 'customWidget/dxWidget/dx_text.dart';

class MatchesScreen extends StatefulWidget {
  static const routeName = 'matches-screen';

  const MatchesScreen({Key? key}) : super(key: key);

  @override
  _MatchesScreenState createState() => _MatchesScreenState();
}

class _MatchesScreenState extends State<MatchesScreen> {
  List<String> matchTypes = [
    "Pending Matches",
    "Request Matches",
    "Completed "
        "Matches"
  ];
  late bool useMobileDevice;
  final _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: matchTypes.length,
      child: Scaffold(
        // backgroundColor: materialPrimaryColor,
        appBar: AppBar(
          elevation: 0,
          automaticallyImplyLeading: false,
          title: DxText(
            "Matches",
            mSize: 35,
            mBold: true,
            textColor: Colors.white,
          ),
          backgroundColor: black_grey,
          actions: <Widget>[
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              child: FloatingActionButton(
                backgroundColor: Colors.grey.shade600,
                foregroundColor: Colors.black,
                mini: true,
                onPressed: () {
                  // Respond to button press
                },
                child: Icon(
                  Icons.menu,
                  color: Colors.white,
                ),
              ),
            )
          ],
          bottom: TabBar(
              indicatorWeight: 1,
              isScrollable: true,
              labelColor: Colors.white,
              unselectedLabelStyle: TextStyle(fontSize: getSize(18, context)),
              // unselectedLabelColor: Colors.white10,
              indicatorSize: TabBarIndicatorSize.label,
              labelStyle: TextStyle(
                  fontWeight: FontWeight.w600, fontSize: getSize(20, context)),
              indicator: BoxDecoration(
                border: Border(
                  bottom: BorderSide(
                    color: Colors.white,
                  ),
                ),
              ),
              tabs: List.generate(
                  matchTypes.length,
                  (index) => Container(
                      height: 38,
                      alignment: Alignment.centerLeft,
                      child: Text(matchTypes[index])))),
        ),
        body: TabBarView(
            children: [PendingMatches(), RequestMatches(), CompleteMatches()]),
      ),
    );
  }
}

class PendingMatches extends StatelessWidget {
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  late bool useMobileDevice;

  @override
  Widget build(BuildContext context) {
    BlocProvider.of<MatchRequestCubit>(context).getPendingReqData();
    useMobileDevice = DeviceInfo.useMobileLayout(context);
    return Scaffold(
      key: _scaffoldKey,
      body: BlocConsumer<MatchRequestCubit, MatchRequestState>(
          builder: (BuildContext context, state) {
        if (state is MatchRequestLoaded) {
          return body(state.opponentData);
        }
        if (state is MatchRequestError) {
          return body([]);
        }
        if (state is MatchRequestInitial) {
          return AppLoaderProgress();
        }

        return Container();
      }, listener: (BuildContext context, state) {
        if (state is MatchRequestError) {
          MethodUtils.showSnackBarGK(_scaffoldKey, "${state.error}");
        }
      }),
    );
  }

  Widget body(List<Requests> opponentData) {
    return opponentData.isEmpty
        ? Center(
            child: DxTextBlack(
              "No Data Found!",
              mBold: true,
            ),
          )
        : GridView.builder(
            padding: const EdgeInsets.all(8),
            itemCount: opponentData.length,
            physics: ClampingScrollPhysics(),
            shrinkWrap: true,
            itemBuilder: (BuildContext context, index) {
              return MatchesBody(
                opponentData[index],
                screenTypes: ScreenTypes.pending,
              );
            },
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 2.0,
                crossAxisSpacing: 3.0,
                childAspectRatio: useMobileDevice ? 6 / 8 : 5 / 3.5),
          );
  }
}

class RequestMatches extends StatelessWidget {
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  late bool useMobileDevice;

  @override
  Widget build(BuildContext context) {
    BlocProvider.of<MatchRequestCubit>(context).getMatchReqData();
    useMobileDevice = DeviceInfo.useMobileLayout(context);
    return Scaffold(
      key: _scaffoldKey,
      body: BlocConsumer<MatchRequestCubit, MatchRequestState>(
          builder: (BuildContext context, state) {
        if (state is MatchRequestLoaded) {
          return body(state.opponentData);
        }
        if (state is MatchRequestError) {
          return body([]);
        }
        if (state is MatchRequestInitial) {
          return AppLoaderProgress();
        }

        return Container();
      }, listener: (BuildContext context, state) {
        if (state is MatchRequestError) {
          MethodUtils.showSnackBarGK(_scaffoldKey, "${state.error}");
        }
      }),
    );
  }

  Widget body(List<Requests> opponentData) {
    return opponentData.isEmpty
        ? Center(
            child: DxTextBlack(
              "No Data Found!",
              mBold: true,
            ),
          )
        : GridView.builder(
            padding: const EdgeInsets.all(8),
            itemCount: opponentData.length,
            physics: ClampingScrollPhysics(),
            shrinkWrap: true,
            itemBuilder: (BuildContext context, index) {
              return MatchesBody(
                opponentData[index],
                screenTypes: ScreenTypes.request,
              );
            },
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 2.0,
                crossAxisSpacing: 3.0,
                childAspectRatio: useMobileDevice ? 6 / 8 : 5 / 3.5),
          );
  }
}

class CompleteMatches extends StatelessWidget {
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  late bool useMobileDevice;

  @override
  Widget build(BuildContext context) {
    BlocProvider.of<MatchRequestCubit>(context).getCompleteReqData();
    useMobileDevice = DeviceInfo.useMobileLayout(context);
    return Scaffold(
      key: _scaffoldKey,
      body: BlocConsumer<MatchRequestCubit, MatchRequestState>(
          builder: (BuildContext context, state) {
        if (state is MatchRequestLoaded) {
          return body(state.opponentData);
        }
        if (state is MatchRequestError) {
          return body([]);
        }
        if (state is MatchRequestInitial) {
          return AppLoaderProgress();
        }

        return Container();
      }, listener: (BuildContext context, state) {
        if (state is MatchRequestError) {
          MethodUtils.showSnackBarGK(_scaffoldKey, "${state.error}");
        }
      }),
    );
  }

  Widget body(List<Requests> opponentData) {
    return opponentData.isEmpty
        ? Center(
            child: DxTextBlack(
              "No Data Found!",
              mBold: true,
            ),
          )
        : GridView.builder(
            padding: const EdgeInsets.all(8),
            itemCount: opponentData.length,
            physics: ClampingScrollPhysics(),
            shrinkWrap: true,
            itemBuilder: (BuildContext context, index) {
              return MatchesBody(
                opponentData[index],
                screenTypes: ScreenTypes.completed,
              );
            },
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                mainAxisSpacing: 2.0,
                crossAxisSpacing: 3.0,
                childAspectRatio: useMobileDevice ? 6 / 8 : 5 / 3.5),
          );
  }
}

class MatchesBody extends StatefulWidget {
  Requests opponentData;
  ScreenTypes screenTypes;

  MatchesBody(this.opponentData, {required this.screenTypes});

  @override
  _MatchesBodyState createState() => _MatchesBodyState();
}

class _MatchesBodyState extends State<MatchesBody> {
  @override
  Widget build(BuildContext context) {
    String image = widget.opponentData.opponent!.playerimage!.split("/").last;
    return Stack(
      children: [
        Container(
          height: 350,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: CachedNetworkImage(
              imageUrl: "http://www"
                  ".sipconline.com/uat/sipl/images/$image",
              placeholder: (context, url) =>
                  Center(child: CupertinoActivityIndicator()),
              fit: BoxFit.cover,
              errorWidget: (context, url, error) => Icon(Icons.error),
            ),
          ),
        ),
        Positioned(
            top: 8,
            left: 8,
            right: 8,
            child: DxTextWhiteM(
              widget.opponentData.opponent!.fullname!,
            )),
        Positioned(
            bottom: 10,
            left: 1,
            right: 1,
            child: buildButton(context, onPressed: () {
              openScreenAsPlatformWiseRoute(
                  context,
                  MatchDetailsScreen(
                    widget.opponentData,
                    screenTypes: widget.screenTypes,
                  )).then((value) {
                if (widget.screenTypes == ScreenTypes.request) {
                  BlocProvider.of<MatchRequestCubit>(context).getMatchReqData();
                } else if (widget.screenTypes == ScreenTypes.pending) {
                  BlocProvider.of<MatchRequestCubit>(context).getPendingReqData();
                } else if (widget.screenTypes == ScreenTypes.completed) {
                  BlocProvider.of<MatchRequestCubit>(context).getCompleteReqData();
                }
              });
            },
                btnName: "View "
                    "Details"))
      ],
    );
  }

  Container buildButton(BuildContext context,
      {String? btnName, required void Function()? onPressed}) {
    return Container(
      // width: MediaQuery.of(context).size.width,
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Center(
        child: RaisedButton(
          elevation: 8.0,
          color: materialAccentColor,
          onPressed: onPressed,
          child: DxTextWhiteM(
            btnName!,
            mBold: true,
          ),
        ),
      ),
    );
  }
}
