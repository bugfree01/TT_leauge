import 'package:flutter/material.dart';
import 'profileScreen.dart';
import 'searchScreen.dart';

import '../helper/app_utilities/appImages.dart';
import 'favouriteScreen.dart';
import 'homePage/homeScreen.dart';
import 'matchesScreen.dart';


class BottomNavigation extends StatefulWidget {
  static const routeName = "bottom-navigation";
  @override
  _BottomNavigationState createState() => _BottomNavigationState();
}

class _BottomNavigationState extends State<BottomNavigation> {
  int _currentIndex = 0;

  List<Widget> _page = [
    HomeScreen(),
    MatchesScreen(),
    SearchScreen(),
    FavouriteScreen(),
    ProfileScreen(),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // drawer: DrawerWidget(),
      // appBar: mainAppBar(context,
      //     title: _currentIndex == 0
      //         ? "Home"
      //         : _currentIndex == 1
      //             ? "My Appointments"
      //             : _currentIndex == 2
      //                 ? "Search"
      //                 : _currentIndex == 3
      //                     ? "Profile"
      //                     : ""),

      body: _page[_currentIndex],
      bottomNavigationBar: _buildBottomNavigationBar(context),
      floatingActionButtonLocation: FloatingActionButtonLocation.miniCenterDocked,
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          setState(() {
            _currentIndex = 2;
          });
        },
        backgroundColor: Colors.white,
        child: Image.asset(
          AppImages.searchIcon,
          color: Colors.blue,
        ),
      ),
    );
  }

  double iconSize = 28;

  BottomNavigationBar _buildBottomNavigationBar(BuildContext context) {
    return BottomNavigationBar(
      type: BottomNavigationBarType.fixed,
      backgroundColor: Colors.white,
      selectedItemColor: Theme.of(context).primaryColor,
      selectedLabelStyle: TextStyle(
        fontWeight: FontWeight.bold,
      ),
      // selectedfontSize: 12.0,
      unselectedItemColor: Color(0xff77838F),
      unselectedLabelStyle: TextStyle(
        fontWeight: FontWeight.bold,
      ),
      currentIndex: _currentIndex,
      onTap: (index) {
        setState(() {
          _currentIndex = index;
        });
        print("_currentIndex bottomBar : $_currentIndex");
      },
      items: <BottomNavigationBarItem>[
        BottomNavigationBarItem(
          icon: Image.asset(
            AppImages.homeIcon,
            height: iconSize,
            width: iconSize,
            color: _currentIndex == 0 ? Color(0xffFF2D55) : null,
          ),
          // label: 'Home',
          title: Text(
            'Home',
            textScaleFactor: 1.5,
            style: TextStyle(
                fontSize: 12.0,
                color: Colors.black,
                fontWeight: FontWeight.bold),
          ),
        ),
        BottomNavigationBarItem(
          icon: Image.asset(
            AppImages.pingpongIcon,
            height: iconSize,
            width: iconSize,
            color: _currentIndex == 1 ? Color(0xffFF2D55) : null,
          ),
          // label: 'Matches',
          title: Text(
            'Matches',
            textScaleFactor: 1.5,
            style: TextStyle(
                fontSize: 12.0,
                color: Colors.black,
                fontWeight: FontWeight.bold),
          ),
        ),
        BottomNavigationBarItem(
          icon: Text(''),
          // label: 'Search',
          title: Text(
            'Search',
            textScaleFactor: 1.5,
            style: TextStyle(
                fontSize: 12.0,
                color: Colors.black,
                fontWeight: FontWeight.bold),
          ),
        ),
        BottomNavigationBarItem(
          icon: Image.asset(
            AppImages.heartIcon,
            height: iconSize,
            width: iconSize,
            color: _currentIndex == 3 ? Color(0xffFF2D55) : null,
          ),
          // label: 'Favourites',
          title: Text(
            'Favourites',
            textScaleFactor: 1.5,
            style: TextStyle(
                fontSize: 12.0,
                color: Colors.black,
                fontWeight: FontWeight.bold),
          ),
        ),
        BottomNavigationBarItem(
          icon: Image.asset(
            AppImages.profileIcon,
            height: iconSize,
            width: iconSize,
            color: _currentIndex == 4 ? Color(0xffFF2D55) : null,
          ),
          // label: 'Profile',
          title: Text(
            'Profile',
            textScaleFactor: 1.5,
            style: TextStyle(
                fontSize: 12.0,
                color: Colors.black,
                fontWeight: FontWeight.bold),
          ),
        ),
      ],
    );
  }
}
