import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:tt_league/Model/userModel.dart';
import 'package:tt_league/cubit/profile/profileShow/profile_show_cubit.dart';
import 'package:tt_league/helper/app_utilities/appImages.dart';
import 'package:tt_league/helper/app_utilities/app_theme.dart';
import 'package:tt_league/helper/app_utilities/method_utils.dart';
import 'package:tt_league/helper/localStorage/preference_handler.dart';
import 'package:tt_league/helper/routeAndBlocManager/navigator.dart';
import 'package:tt_league/screen/authentication/LoginScreen.dart';
import 'package:tt_league/screen/subPages/editProfile.dart';

import 'customWidget/app_circular_loader.dart';
import 'customWidget/dxWidget/dx_text.dart';

class ProfileScreen extends StatefulWidget {
  static const routeName = '/profile-screen';

  const ProfileScreen({Key? key}) : super(key: key);

  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {

  final _scaffoldKey = GlobalKey<ScaffoldState>();

  late String ? name,
      wPercentage,
      matches,
      wins, credits, earnedCredits,
      age,
      location,
      about,
      playerLevel,
      image;
 UserModel? userModel;
  late String goldWin, silveWin, bronzeWin, pLocation, tShirt;

  // String image = "http://www.sipconline.com/uat/sipl/images";

  bool loader = true;

  @override
  void initState() {
    BlocProvider.of<ProfileShowCubit>(context).validateFromServer();

    super.initState();
  }

  void getUserData(UserModel userModel) async {
    goldWin = userModel.goldwins!;
    silveWin = userModel.silverwins!;
    bronzeWin = userModel.bronzewins!;
    tShirt = userModel.tshirt!;
    name = userModel.fullname!;
    about = userModel.description!;
    age = userModel.age!;
    wins = userModel.wins!.toString();
    wPercentage = userModel.percentage!;
    matches = userModel.matches!.toString();
    location = userModel.location!;
    pLocation = userModel.preflocation!;
    playerLevel = userModel.playerlevel!;
    String dimage = userModel.image1
        .split("/")
        .last;
    image = dimage;
    credits = userModel.credits!;
    earnedCredits = userModel.earnedCredits!;
    setState(() {
      loader = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      body: BlocConsumer<ProfileShowCubit, ProfileShowState>(
          builder: (BuildContext context, state) {
            if (state is ProfileShowLoaded) {
              return mainBody();
            }
            if (state is ProfileShowError) {
              return mainBody();
            }
            if (state is ProfileShowInitial) {
              return AppLoaderProgress();
            }
            return Container();
          }, listener: (BuildContext context, state) {
        if (state is ProfileShowLoaded) {
          this.userModel = state.userModel;
          getUserData(state.userModel);
        }
        if (state is ProfileShowError) {
          MethodUtils.showSnackBarGK(_scaffoldKey, "${state.error}");
        }
      }),
    );
  }

  Widget mainBody() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Stack(
            children: [
              Container(
                height: 180,
                color: Color(0xff4A4A4A),
              ),
              Container(
                margin:
                const EdgeInsets.only(left: 16.0, right: 16.0, top: 80.0),
                padding: const EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12.0),
                    boxShadow: [
                      BoxShadow(
                        color: Color(0xff000000).withOpacity(0.2),
                        blurRadius: 5.0,
                      ),
                    ]),
                child: Column(
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        CircleAvatar(
                            radius: 40,
                            backgroundImage: NetworkImage("http://www"
                                ".sipconline.com/uat/sipl/images/$image",)
                        ),
                        Expanded(
                          flex: 1,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                padding: const EdgeInsets.all(16.0),
                                // child: buildHeading(name == ""?'':name,maxLine:2),
                                child: DxTextBlack(
                                  name == "" ? "" : name!, maxLine:
                                2, mBold: true,),
                              ),
                              buildBody(
                                  title: location == "" ? '' : location,
                                  color:
                                  Colors.grey),
                            ],
                          ),
                        ),
                        SizedBox(width: 25),
                        IconButton(
                          icon: Icon(Icons.edit), color: materialAccentColor,
                          onPressed: () {
                            openScreenAsPlatformWiseRoute(context, EditProfile
                              ()).then((value) =>
                                BlocProvider.of<ProfileShowCubit>(context)
                                    .validateFromServer());
                          },)
                      ],
                    ),
                    SizedBox(height: 40.0),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        buildTopCounterCard(title: 'Winning',
                            value: "$wPercentage %"),
                        buildTopCounterCard(title: 'Wins', value: wins),
                        buildTopCounterCard(title: 'Matches', value: matches),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Flexible(
                flex: 2,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    buildHeading(name == "" ? '' : name),
                    buildBody(
                        title: location == "" ? '' : location,
                        color:
                        Colors.grey),
                  ],
                ),
              ),
              Flexible(
                flex: 1,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    age!.isNotEmpty ? Container(
                      width: 80,
                      margin: EdgeInsets.only(top: 20),
                      padding: EdgeInsets.symmetric(vertical: 8, horizontal: 4),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8),
                        gradient: LinearGradient(
                          begin: Alignment.topRight,
                          end: Alignment.bottomLeft,
                          stops: [0.1, 0.5, 0.7, 0.9],
                          colors: [
                            Color(0xffFF8960),
                            Color(0xffFF8960),
                            Color(0xffFF689A),
                            Color(0xffFF689A),
                          ],
                        ),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          // Image.asset(AppImages.womanIcon, width: 20),
                          // SizedBox(width: 4.0),
                          DxTextWhiteM(
                              age!,
                              mSize: 18,
                              mBold: true
                          ),
                        ],
                      ),
                    ) : SizedBox.shrink(),
                    // playerLevel!.isNotEmpty ?  buildBody(title:playerLevel,
                    //     color: materialAccentColor,bold: true) : SizedBox.shrink(),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    CircleAvatar(
                      backgroundColor: Color(0xffEFEFEF),
                      child: Icon(
                        Icons.more_horiz,
                        color: Color(0xffC1C0C9),
                      ),
                    ),
                    SizedBox(height: 10.0),
                  ],
                ),
              ),
            ],
          ),
          about!.isNotEmpty ? aboutBody() : SizedBox.shrink(),
          // buildHeading('Interests'),
          // Padding(
          //   padding: const EdgeInsets.symmetric(horizontal: 8.0),
          //   child: Wrap(
          //     spacing: 5.0,
          //     runSpacing: 3.0,
          //     children: _buildChoiceList(),
          //   ),
          // ),
          SizedBox(height: 30),
          Container(
            margin: EdgeInsets.symmetric(horizontal: 15),
            padding: EdgeInsets.symmetric(vertical: 15),
            decoration: BoxDecoration(
                border: Border.all(color: Colors.grey),
                borderRadius: BorderRadius.circular(4)
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                buildTopCounterCard(title: 'Credits',
                    value: credits!),
                buildTopCounterCard(title: 'Earned Credits',
                    value: earnedCredits!),
                buildTopCounterCard(title: 'Player Level', value: playerLevel!),
              ],
            ),
          ),
          SizedBox(height: 25),

          subItms(title: "Preferred Location", value: pLocation),
          Divider(height: 30),
          subItms(title: "Gold Wins", value: goldWin),
          Divider(height: 30),
          subItms(title: "Silver Wins", value: silveWin),
          Divider(height: 30),
          subItms(title: "Bronze Wins", value: bronzeWin),
          Divider(height: 30),
          subItms(title: "T-Shirt", value: tShirt),
          Divider(height: 30),
          InkWell(
            onTap: () {
              PreferenceHandler.clearPref();
              Navigator.pushAndRemoveUntil(context,
                  MaterialPageRoute(builder: (context) => LoginScreen()), (
                      route) => false);
            },
            child: buildBody(title: "Logout", color: Colors.black),
          ),

          SizedBox(height: 25)

        ],
      ),
    );
  }

  Widget aboutBody() {
    return Column(children: [
      buildHeading('About'),
      buildBody(
          title: about,
          maxLine: 3,
          color: Colors.black),
      SizedBox(height: 16),
      InkWell(
        onTap: () => setState(() => showText = !showText),
        child: buildBody(
            title: !showText ? 'Show more' : 'Show less',
            color: Theme
                .of(context)
                .accentColor),
      ),
    ],);
  }

  Widget subItms({String title = "", String value = ""}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        buildBody(title: title, color: Colors.grey),
        buildBody(title: value, color: Colors.black),
      ],);
  }

  Column buildTopCounterCard({String? title, String? value}) {
    return Column(
      children: [
        Text(
          title!,
          style: Theme
              .of(context)
              .textTheme
              .bodyText1!
              .copyWith(color: Colors.grey, fontSize: 14),
        ),
        SizedBox(height: 8.0),
        Text(
          value!,
          style: Theme
              .of(context)
              .textTheme
              .bodyText1!
              .copyWith(color: Colors.black, fontWeight: FontWeight.bold),
        ),
      ],
    );
  }

  bool showText = false;

  Padding buildHeading(String? title, {int maxLine = 1}) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: DxTextBlack(
        title!,
        mSize: 18,
        maxLine: maxLine,
        mBold: true,
        overflow: TextOverflow.ellipsis,
      ),
    );
  }

  Padding buildBody({String? title, Color? color, bool bold = false, int
  maxLine = 1}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0),
      child: DxText(
        title!,
        textColor: color!,
        mSize: 18,
        overflow: TextOverflow.ellipsis,
        mBold: bold,
        maxLines: maxLine,
      ),
    );
  }
}
