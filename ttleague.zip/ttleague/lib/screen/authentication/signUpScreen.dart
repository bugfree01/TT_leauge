import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:tt_league/helper/app_utilities/app_theme.dart';
import 'package:tt_league/screen/customWidget/dxWidget/dx_text.dart';
import 'singlesSignUp.dart';

import 'LoginScreen.dart';
import '../../helper/app_utilities/appImages.dart';
import 'doublesSignUp.dart';
import 'mixedSignUp.dart';

class SignUpScreen extends StatefulWidget {
  static const routeName = '/sign-up-screen';

  const SignUpScreen({Key? key}) : super(key: key);

  @override
  _SignUpScreenState createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  late Size size;
  @override
  Widget build(BuildContext context) {
    size = MediaQuery.of(context).size;
    return Scaffold(
        backgroundColor: materialPrimaryColor,
        appBar: AppBar(toolbarHeight: 0.0, backgroundColor: Colors.transparent),
        body: body());
  }

  Widget body() {
    return SingleChildScrollView(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 25,vertical: 50),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              width: double.infinity,
              height: 45,
              child: Image.asset(AppImages.logo),
            ),
            SizedBox(height: size.height*0.02,),
            Container(
              child: FittedBox(
                child: DxTextYellow(
                  'Singapore International Paddlers\nLeague',
                  textAlign: TextAlign.center,
                  mSize: 18,
                ),
              ),
            ),
            Container(
              margin:
              const EdgeInsets.symmetric(horizontal: 60, vertical: 40),
              child: RichText(
                textAlign: TextAlign.center,
                text: TextSpan(
                  text: 'Choose your category to Sign up',
                  style: TextStyle(
                    fontFamily: 'SF-UI-Text-Regular',
                    fontSize: 16.0,
                    color: Colors.white70,
                  ),
                ),
              ),
            ),
            buildButton(context,
                title: 'Open Singles',
                onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => SinglesSignUp()))),
            SizedBox(height: 36),
            buildButton(context,
                title: 'Open Doubles',
                onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => DoublesSignUp()))),
            SizedBox(height: 36),
            buildButton(context,
                title: 'Mixed Team',
                onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (context) => MixedSignUp()))),

            // Expanded(
            //   child: Column(
            //     crossAxisAlignment: CrossAxisAlignment.center,
            //     children: [
            //       Padding(
            //         padding: const EdgeInsets.fromLTRB(48, 80, 48, 20),
            //         child: Image.asset(AppImages.logo),
            //       ),
            //       Container(
            //         // color: Colors.blue,
            //         padding: const EdgeInsets.fromLTRB(48, 0, 48, 30),
            //         child: FittedBox(
            //           child: DxTextYellow(
            //             'Singapore International Paddlers\nLeague',
            //             textAlign: TextAlign.center,
            //             mSize: 20,
            //           ),
            //         ),
            //       ),
            //       Container(
            //         margin:
            //             const EdgeInsets.symmetric(horizontal: 60, vertical: 40),
            //         child: RichText(
            //           textAlign: TextAlign.center,
            //           text: TextSpan(
            //             text: 'Choose your category to Sign up',
            //             style: TextStyle(
            //               fontFamily: 'SF-UI-Text-Regular',
            //               fontSize: 18.0,
            //               color: Colors.white70,
            //             ),
            //           ),
            //         ),
            //       ),
            //       buildButton(context,
            //           title: 'Open Singles',
            //           onPressed: () => Navigator.push(
            //               context,
            //               MaterialPageRoute(
            //                   builder: (context) => SinglesSignUp()))),
            //       SizedBox(height: 36),
            //       buildButton(context,
            //           title: 'Open Doubles',
            //           onPressed: () => Navigator.push(
            //               context,
            //               MaterialPageRoute(
            //                   builder: (context) => DoublesSignUp()))),
            //       SizedBox(height: 36),
            //       buildButton(context,
            //           title: 'Mixed Team',
            //           onPressed: () => Navigator.push(
            //               context,
            //               MaterialPageRoute(
            //                   builder: (context) => MixedSignUp()))),
            //     ],
            //   ),
            // ),
            // Container(
            //   margin: const EdgeInsets.symmetric(horizontal: 60, vertical: 40),
            //   child: RichText(
            //     textAlign: TextAlign.center,
            //     text: TextSpan(
            //         text: 'Already have an account? ',
            //         style: TextStyle(
            //           fontFamily: 'SF-UI-Text-Regular',
            //           fontSize: 18.0,
            //           color: Colors.white70,
            //         ),
            //         children: <TextSpan>[
            //           TextSpan(
            //             text: 'SIGNIN',
            //             style: TextStyle(
            //               fontFamily: 'SF-UI-Text-Regular',
            //               fontSize: 18.0,
            //               color: Colors.white70,
            //             ),
            //             recognizer: TapGestureRecognizer()
            //               ..onTap = () {
            //                 Navigator.pushNamedAndRemoveUntil(
            //                     context, LoginScreen.routeName, (route) => false);
            //               },
            //           ),
            //         ]),
            //   ),
            // ),
          ],
        ),
      ),
    );
  }

  Container buildButton(BuildContext context,
      {String? title, required void Function()? onPressed}) {
    return Container(
      width: MediaQuery.of(context).size.width - 150,
      child: RaisedButton(
        elevation: 8.0,
        color: materialAccentColor,
        onPressed: onPressed,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 14),
          child: DxTextWhiteM(
            title!,mSize: 18,mBold: true,
          ),
        ),
      ),
    );
  }
}
