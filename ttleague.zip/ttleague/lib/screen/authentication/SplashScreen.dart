import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:tt_league/helper/app_utilities/appImages.dart';
import 'package:tt_league/helper/localStorage/preference_handler.dart';
import 'package:tt_league/helper/routeAndBlocManager/navigator.dart';
import 'package:video_player/video_player.dart';
import '../bottomNavigation.dart';
import 'LoginScreen.dart';
import '../../helper/app_utilities/colors.dart';


class SplashScreen extends StatefulWidget {


  _SplashScreen createState() => _SplashScreen();
}

class _SplashScreen extends State<SplashScreen> {
  late VideoPlayerController _controller;

  @override
  void initState() {
    _controller = VideoPlayerController.asset('assets/videos/splashVideo.mp4');
    // _controller.addListener(() {
    //   setState(() {});
    // });
    _controller.setLooping(true);
    _controller.initialize().then((_) => setState(() {}));
    _controller.play();
    super.initState();
    startTimer();
  }

  void startTimer() {
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
    Future.delayed(Duration(seconds: 2), () => navigateInside());
  }

  void navigateInside() async {

    final _isloggedIn =  await PreferenceHandler.isLogIn();

    print("Your prfe home ${_isloggedIn}");
    if (_isloggedIn) {
      openScreenAsPlatformWiseRoute(context, BottomNavigation(),
          isExit: true);
    } else {
      Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context) => LoginScreen()), (route) => false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color:black_grey,
        child: Stack(
          children: <Widget>[
            VideoPlayer(_controller),
            // new Positioned(
            //     child: Align(
            //         alignment: Alignment.center,
            //         child: getImageAssets()
            //     )
            // )
          ],
        ),

      ),
    );
  }

  Widget getImageAssets() {
    return Container(
        height: 50,
        width: 300,
        child: Image.asset(AppImages.logo));
  }

}
