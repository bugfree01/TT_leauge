import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:tt_league/helper/app_utilities/app_theme.dart';
import 'package:tt_league/screen/customWidget/dxWidget/dx_text.dart';

import '../../helper/app_utilities/appImages.dart';

class MixedSignUp extends StatefulWidget {
  static const routeName = '/mixed-sign-up';
  const MixedSignUp({Key? key}) : super(key: key);

  @override
  _MixedSignUpState createState() => _MixedSignUpState();
}

class _MixedSignUpState extends State<MixedSignUp> {
  bool showSignupForm = false;

  TextEditingController usernameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  String? selectedPlayerLevel = 'Basic';
  List<String> playerLevelDropdown = ['Basic', 'Intermediate', 'Advanced'];

  @override
  void dispose() {
    usernameController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: materialPrimaryColor,
        appBar: AppBar(toolbarHeight: 0.0, backgroundColor: Colors.transparent),
        body: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(48, 40, 48, 20),
                child: Image.asset(AppImages.logo),
              ),
              Container(
                // color: Colors.blue,
                padding: const EdgeInsets.fromLTRB(48, 0, 48, 30),
                child: FittedBox(
                  child: DxTextYellow(
                    showSignupForm
                        ? 'Mixed Team Sign up'
                        : 'Singapore International Paddlers\nLeague',
                    textAlign: TextAlign.center,
                   mSize: 20,mBold: true,
                  ),
                ),
              ),
              if (showSignupForm)
                Column(
                  children: [
                    buildTextField(
                      heading: "Team Name",
                      hintText: 'Your Team Name',
                      controller: usernameController,
                      obscureText: false,
                    ),
                    SizedBox(height: 20),
                    Text(
                      'Captain Details',
                      style: TextStyle(
                          fontFamily: 'Montserrat-SemiBold',
                          fontSize: 16.0,
                          color: Colors.grey,
                          fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 20),
                    buildTextField(
                      heading: "Full Name",
                      hintText: 'Your Full Name',
                      controller: usernameController,
                      obscureText: false,
                    ),
                    SizedBox(height: 20),
                    buildTextField(
                      heading: "Email Address",
                      hintText: 'Your Email Address',
                      controller: usernameController,
                      obscureText: false,
                    ),
                    SizedBox(height: 20),
                    buildTextField(
                      heading: "Mobile Number (for notifications)",
                      hintText: 'Mobile- 8 digits only',
                      controller: usernameController,
                      obscureText: false,
                    ),
                    SizedBox(height: 20),
                    buildTextField(
                      heading: "Password",
                      hintText: '* * * * * * * * * *',
                      controller: passwordController,
                      obscureText: true,
                    ),
                    SizedBox(height: 20),
                    buildTextField(
                      heading: "Repeat Password",
                      hintText: '* * * * * * * * * *',
                      controller: passwordController,
                      obscureText: true,
                    ),
                    SizedBox(height: 20),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Text(
                        message1!,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            fontFamily: 'Montserrat-SemiBold',
                            fontSize: 16.0,
                            color: Colors.white70,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                    SizedBox(height: 20),
                    buildTextField(
                      heading: "",
                      hintText: 'Player 1 email id *',
                      controller: usernameController,
                      obscureText: false,
                      isHeading: false,
                    ),
                    SizedBox(height: 10),
                    buildTextField(
                      heading: "",
                      hintText: 'Player 2 email id *',
                      controller: usernameController,
                      obscureText: false,
                      isHeading: false,
                    ),
                    SizedBox(height: 10),
                    buildTextField(
                      heading: "",
                      hintText: 'Player 3 email id *',
                      controller: usernameController,
                      obscureText: false,
                      isHeading: false,
                    ),
                    SizedBox(height: 10),
                    buildTextField(
                      heading: "",
                      hintText: 'Player 4 email id *',
                      controller: usernameController,
                      obscureText: false,
                      isHeading: false,
                    ),
                    SizedBox(height: 10),
                    buildTextField(
                      heading: "",
                      hintText: 'Player 5 email id *',
                      controller: usernameController,
                      obscureText: false,
                      isHeading: false,
                    ),
                    SizedBox(height: 10),
                    buildTextField(
                      heading: "",
                      hintText: 'Player 6 email id *',
                      controller: usernameController,
                      obscureText: false,
                      isHeading: false,
                    ),
                    SizedBox(height: 10),
                    buildTextField(
                      heading: "",
                      hintText: 'Player 7 email id *',
                      controller: usernameController,
                      obscureText: false,
                      isHeading: false,
                    ),
                    SizedBox(height: 10),
                    buildTextField(
                      heading: "",
                      hintText: 'Player 8 email id *',
                      controller: usernameController,
                      obscureText: false,
                      isHeading: false,
                    ),
                    SizedBox(height: 40),
                  ],
                )
              else
                Column(
                  children: [
                    SizedBox(height: 40),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20),
                      child: Text(
                        message2!,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            fontFamily: 'Montserrat-SemiBold',
                            fontSize: 16.0,
                            color: Colors.white70,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                    SizedBox(height: 60),
                  ],
                ),
              buildSubmitButton(context),
              SizedBox(height: 40),
            ],
          ),
        ));
  }

  Padding buildTextField({
    bool isHeading = true,
    bool obscureText = false,
    String? heading,
    String? hintText,
    String? Function(String?)? validator,
    TextEditingController? controller,
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 60),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (isHeading)
            Text(
              heading!,
              style: TextStyle(
                  fontFamily: 'Montserrat-SemiBold',
                  fontSize: 14.0,
                  color: Colors.grey,
                  fontWeight: FontWeight.bold),
            ),
          if (isHeading) SizedBox(height: 10),
          Container(
            color: Colors.black54,
            child: TextFormField(
              cursorColor: Colors.white,
              obscureText: obscureText,
              controller: controller,
              validator: validator,
              style: TextStyle(color: Colors.white),
              decoration: InputDecoration(
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.black54,
                  ),
                  gapPadding: 0.0,
                ),
                disabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.black54,
                  ),
                ),
                errorBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.black54,
                  ),
                ),
                focusedErrorBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.black54,
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.white,
                  ),
                ),
                hintText: hintText,
                hintStyle: TextStyle(
                  fontFamily: 'Montserrat-SemiBold',
                  fontSize: 14.0,
                  color: Colors.white60,
                ),
                contentPadding: const EdgeInsets.symmetric(
                    vertical: 16.0, horizontal: 20.0),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Container buildSubmitButton(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width - 150,
      child: RaisedButton(
        elevation: 8.0,
        color: materialAccentColor,
        onPressed: () {
          if (showSignupForm) {
            print('Sign up form submit');
          } else {
            setState(() {
              showSignupForm = !showSignupForm;
            });
          }
        },
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 14),
          child: DxTextWhiteM(
            showSignupForm ? 'Register' : 'Mixed Team',
           mBold: true,mSize: 18,
          ),
        ),
      ),
    );
  }
}

String? message1 =
    'Enter email ids of your teammates, if they are not registered in ttleague, they will receive an email with the registration link';

String? message2 = '''You can enroll up to 8 players per
team
Only 4 players can play in any league match in order to comply with COVID-19 restrictions.

Match Format: 3 Singles and 2 Doubles with a Maximum of 4 players per match in a pre-assigned venue.''';
