import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:tt_league/Model/statisticModel.dart';
import 'package:tt_league/cubit/authentication/login/login_cubit.dart';
import 'package:tt_league/helper/app_utilities/appImages.dart';
import 'package:tt_league/helper/app_utilities/app_theme.dart';
import 'package:tt_league/helper/app_utilities/dx_app_decoration.dart';
import 'package:tt_league/helper/app_utilities/method_utils.dart';
import 'package:tt_league/helper/routeAndBlocManager/navigator.dart';
import 'package:tt_league/screen/customWidget/app_circular_loader.dart';
import 'package:tt_league/screen/customWidget/dxWidget/dx_text.dart';
import 'package:tt_league/screen/subPages/leaderboard.dart';
import 'package:video_player/video_player.dart';
import 'forgotPassword.dart';
import 'signUpScreen.dart';

import '../bottomNavigation.dart';

class LoginScreen extends StatefulWidget {
  static const routeName = '/login-screen';

  const LoginScreen({Key? key}) : super(key: key);

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  TextEditingController usernameController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  bool debud = true;
  late VideoPlayerController _controller;
  StatisticModel? statisticModel;
  bool paswwordHiden = true;

  @override
  void initState() {
    _controller = VideoPlayerController.asset('assets/videos/loginVideo.mp4');
    // _controller.addListener(() {
    //   setState(() {});
    // });
    _controller.setLooping(true);
    _controller.initialize().then((_) => setState(() {}));
    _controller.play();
    if (kDebugMode) {
      usernameController.text = "simmvar@yahoo.com";
      passwordController.text = "resetmypassword";
    }

    BlocProvider.of<LoginCubit>(context).getStatistic();
    super.initState();
  }

  @override
  void dispose() {
    usernameController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        key: _scaffoldKey,
        backgroundColor: materialPrimaryColor,
        appBar: AppBar(toolbarHeight: 0.0, backgroundColor: Colors.transparent),
        body: BlocConsumer<LoginCubit, LoginState>(
            builder: (BuildContext context, state) {
          if (state is LoginLoaded) {
            return body();
          }
          if (state is LoginError) {
            return body();
          }
          if (state is LoginInitial) {
            return AppLoaderProgress();
          }
          if (state is LoginStatisticLoaded) {
            statisticModel = state.statisticModel;
            return body();
          }
          if (state is LoginLoading) {
            return Stack(
              children: [body(), AppLoaderProgress()],
            );
          }

          return Container();
        }, listener: (BuildContext context, state) {
          if (state is LoginLoaded) {
            openScreenAsPlatformWiseRoute(context, BottomNavigation(),
                isExit: true);
          }
          if (state is LoginError) {
            MethodUtils.showSnackBarGK(_scaffoldKey, "${state.errorMSg}");
          }
        }));
  }

  Widget body() {
    return Stack(
      children: [
        Opacity(opacity: .2, child: VideoPlayer(_controller)),
        SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(48, 80, 48, 20),
                child: getImageAssets(),
              ),
              Container(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    statisticBody("${statisticModel?.users ?? "0"}", "Players"),
                    SizedBox(width:8),
                    statisticBody("${statisticModel?.teams ?? "0"}", "Teams"),
                    // statisticBody("${statisticModel?.tournaments ?? "0"}", "Tournam"
                    //     "ents"),
                    // statisticBody("${statisticModel?.requests ?? "0"}","Requests"),
                  ],
                ),
              ),
              Container(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // statisticBody("${statisticModel?.users ?? "0"}", "Players"),
                    // statisticBody("${statisticModel?.teams ?? "0"}", "Teams"),
                    statisticBody("${statisticModel?.tournaments ?? "0"}", "Tournaments"),
                    SizedBox(width: 5),
                    statisticBody("${statisticModel?.requests ?? "0"}","Requests"),
                  ],
                ),
              ),
              SizedBox(
                height: 20,
              ),
              buildTextField(
                heading: "Username",
                hintText: 'Your username here',
                controller: usernameController,
                obscureText: false,
              ),
              SizedBox(height: 20),
              buildTextField(
                heading: "Password",
                hintText: '* * * * * * * * * *',
                controller: passwordController,
                obscureText: paswwordHiden,
                eyeShow: true
              ),
              SizedBox(height: 48),
              buildApplyButton(context),
              SizedBox(height: 20),
              Container(
                width: MediaQuery.of(context).size.width - 140,
                child: InkWell(
                  onTap: ()=>openScreenAsLeftToRight(context,ForgotPassword()),
                  child: DxTextWhite(
                    'Forgot Password?',
                    textAlign: TextAlign.right,
                  ),
                ),
              ),
              Container(
                margin:
                    const EdgeInsets.symmetric(horizontal: 60, vertical: 40),
                child: RichText(
                  textAlign: TextAlign.center,
                  text: TextSpan(
                      text: 'Don’t have account? ',
                      style: TextStyle(
                        fontFamily: 'SF-UI-Text-Regular',
                        fontSize: 18.0,
                        color: Colors.white70,
                      ),
                      children: <TextSpan>[
                        TextSpan(
                          text: 'SIGNUP',
                          style: TextStyle(
                            fontFamily: 'SF-UI-Text-Regular',
                            fontSize: 18.0,
                            color: Colors.white70,
                          ),
                          recognizer: TapGestureRecognizer()
                            ..onTap = () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => SignUpScreen()));
                            },
                        ),
                      ]),
                ),
              ),
              // Container(
              //   width: 130,
              //   padding:
              //       const EdgeInsets.symmetric(vertical: 4, horizontal: 12),
              //   decoration: BoxDecoration(
              //       color: Color(0xff63A8D6),
              //       borderRadius: BorderRadius.circular(8.0),
              //       boxShadow: [
              //         BoxShadow(
              //           color: Colors.black45,
              //           blurRadius: 5.0,
              //         ),
              //       ]),
              //   child: Text(
              //     'Ongoing\nTournaments',
              //     textAlign: TextAlign.center,
              //     style: TextStyle(
              //       fontFamily: 'Montserrat-SemiBold',
              //       fontSize: 14.0,
              //       color: Color(0xffFDFFFF),
              //     ),
              //   ),
              // ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 25,vertical: 8),
                child: DxTextWhite(
                  'By clicking start, you agree to our Terms and Conditions ',
                  textAlign: TextAlign.center,
                ),
              ),
            ],
          ),
        )
      ],
    );
  }

  Widget statisticBody(String data, String name) {
    return Container(
      alignment: Alignment.center,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          DxTextWhiteM(data),
          SizedBox(width: 5),
          InkWell(
            onTap: () {
              openScreenAsLeftToRight(context, LeaderBoard());
            },
            child: DxText(
              name,
              mBold: true,
              mSize: 18,
              textColor: Colors.blueAccent,
            ),
          )
        ],
      ),
    );
  }

  Padding buildTextField({
    bool obscureText = false,
    String? heading,
    String? hintText,
    String? Function(String?)? validator,
    TextEditingController? controller,
    bool eyeShow = false
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 60),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          DxTextWhiteM(
            heading!,
          ),
          SizedBox(height: 10),
          Container(
            color: Colors.black54,
            child: TextFormField(
              cursorColor: Colors.white,
              obscureText: obscureText,
              controller: controller,
              validator: validator,
              style: TextStyle(color: Colors.white),
              decoration: InputDecoration(
                suffixIcon:eyeShow ? IconButton(
                  color: Colors.white,
                  icon: paswwordHiden ? Icon(Icons.visibility_off):Icon(Icons.visibility),
                  onPressed: (){
                    setState(() {
                      paswwordHiden=!paswwordHiden;
                    });
                  },
                ):null,
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.black,
                  ),
                  gapPadding: 0.0,
                ),
                disabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.black,
                  ),
                ),
                errorBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.black,
                  ),
                ),
                focusedErrorBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.black,
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.white,
                  ),
                ),
                hintText: hintText,
                hintStyle: TextStyle(
                  fontFamily: 'Montserrat-SemiBold',
                  fontSize: 14.0,
                  color: Colors.white60,
                ),
                contentPadding: const EdgeInsets.symmetric(
                    vertical: 16.0, horizontal: 20.0),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Container buildApplyButton(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width - 150,
      child: RaisedButton(
        elevation: 8.0,
        color: materialAccentColor,
        onPressed: () {
          BlocProvider.of<LoginCubit>(context).validateFromServer(
              usernameController.text, passwordController.text);
          // Navigator.push(context,
          //     MaterialPageRoute(builder: (context) => BottomNavigation()));
        },
        child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 14),
            child: DxTextWhite(
              "Login",
              mBold: true,
              mSize: 20,
            )),
      ),
    );
  }

  Widget getImageAssets() {
    return Container(
      child: Image.asset(AppImages.logo),
      width: 300,
      height: 45,
    );
  }
}
