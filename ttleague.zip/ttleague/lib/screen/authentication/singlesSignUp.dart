import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:tt_league/Model/userModel.dart';
import 'package:tt_league/cubit/authentication/SignUp/signup_cubit.dart';
import 'package:tt_league/helper/app_utilities/app_theme.dart';
import 'package:tt_league/helper/app_utilities/dx_app_decoration.dart';
import 'package:tt_league/helper/app_utilities/method_utils.dart';
import 'package:tt_league/screen/customWidget/app_circular_loader.dart';
import 'package:tt_league/screen/customWidget/dxWidget/dx_text.dart';

import '../../helper/app_utilities/appImages.dart';

class SinglesSignUp extends StatefulWidget {
  static const routeName = '/singles-sign-up';

  const SinglesSignUp({Key? key}) : super(key: key);

  @override
  _SinglesSignUpState createState() => _SinglesSignUpState();
}

class _SinglesSignUpState extends State<SinglesSignUp> {
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController fullNameController = TextEditingController();
  TextEditingController mobileController = TextEditingController();
  TextEditingController cPasswordController = TextEditingController();
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  String? selectedPlayerLevel = 'Basic';
  bool passHidden = true;
  bool cPassHidden = true;
  List<String> playerLevelDropdown = ['Basic', 'Intermediate', 'Advanced'];

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    fullNameController.dispose();
    mobileController.dispose();
    cPasswordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    print("your val is ${'""'}");
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: materialPrimaryColor,
      appBar: AppBar(
          toolbarHeight: 0.0,
          backwardsCompatibility: false,
          backgroundColor: Colors.transparent),
      body: BlocConsumer<SignupCubit, SignupState>(
          builder: (BuildContext context, state) {
        if (state is SignupInitial) {
          return body();
        }
        if (state is SignupLoaded) {
          return body();
        }
        if (state is SignupError) {
          return body();
        }
        if (state is SignupLoading) {
          return Stack(
            children: [body(), AppLoaderProgress()],
          );
        }

        return Container();
      }, listener: (BuildContext context, state) {
        if (state is SignupError) {
          MethodUtils.showSnackBarGK(_scaffoldKey, "${state.errorMsg}");
        }
      }),
    );
  }

  Widget body() {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(48, 40, 48, 20),
            child: Image.asset(AppImages.logo),
          ),
          Container(
            // color: Colors.blue,
            padding: const EdgeInsets.fromLTRB(48, 0, 48, 30),
            child: FittedBox(
              child: DxTextYellow(
                'Open Single Sign up',
                textAlign: TextAlign.center,
                mBold: true,
                mSize: 20,
              ),
            ),
          ),
          buildTextField(
              heading: "Full Name",
              hintText: 'Your Full Name',
              controller: fullNameController,
              obscureText: false,
              inputFormatters: [
                LengthLimitingTextInputFormatter(20),
              ]),
          SizedBox(height: 20),
          buildTextField(
              heading: "Email Address",
              hintText: 'Your Email Address',
              controller: emailController,
              obscureText: false,
              inputFormatters: [
                LengthLimitingTextInputFormatter(35),
              ]),
          SizedBox(height: 20),
          buildTextField(
              heading: "Mobile Number",
              hintText: 'Mobile Number',
              controller: mobileController,
              obscureText: false,
              keyboardType: TextInputType.number,
              inputFormatters: [
                LengthLimitingTextInputFormatter(15),
              ]),
          SizedBox(height: 20),
          buildTextField(
              heading: "Password",
              hintText: '* * * * * * * * * *',
              controller: passwordController,
              obscureText: passHidden,
              suffixIcon: IconButton(
                color: Colors.white,
                icon: passHidden ? Icon(Icons.visibility_off):Icon(Icons.visibility),
                onPressed: (){
                  setState(() {
                    passHidden=!passHidden;
                  });
                },
              ),
              inputFormatters: [
                LengthLimitingTextInputFormatter(35),
              ]),
          SizedBox(height: 20),
          buildTextField(
              heading: "Repeat Password",
              hintText: '* * * * * * * * * *',
              controller: cPasswordController,
              obscureText: cPassHidden,
              suffixIcon: IconButton(
                color: Colors.white,
                icon: cPassHidden ? Icon(Icons.visibility_off):Icon(Icons.visibility),
                onPressed: (){
                  setState(() {
                    cPassHidden=!cPassHidden;
                  });
                },
              ),
              inputFormatters: [
                LengthLimitingTextInputFormatter(35),
              ]),
          SizedBox(height: 20),
          buildPlayerLevelDropdown(),
          SizedBox(height: 30),
          buildSubmitButton(context),
          Padding(
            padding: const EdgeInsets.fromLTRB(60, 40, 60, 20),
            child: DxTextWhite(
              'By clicking start, you agree to our Terms and Conditions ',
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }

  Column buildPlayerLevelDropdown() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 60),
          child: Text(
            'Player Level',
            style: TextStyle(
                fontFamily: 'Montserrat-SemiBold',
                fontSize: 14.0,
                color: Colors.grey,
                fontWeight: FontWeight.bold),
          ),
        ),
        SizedBox(height: 10),
        Container(
          margin: const EdgeInsets.symmetric(horizontal: 60),
          padding: const EdgeInsets.symmetric(vertical: 16),
          color: Colors.black54,
          child: DropdownButton<String>(
            dropdownColor: Colors.black87,
            isDense: true,
            value: selectedPlayerLevel,
            key: UniqueKey(),
            isExpanded: true,
            underline: Container(),
            items: playerLevelDropdown
                .map(
                  (level) => DropdownMenuItem<String>(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20.0),
                      child: Text(
                        level,
                        style: TextStyle(
                          fontFamily: 'Montserrat-SemiBold',
                          fontSize: 14.0,
                          color: Colors.white60,
                        ),
                      ),
                    ),
                    value: level,
                  ),
                )
                .toList(),
            onChanged: (val) {
              setState(() {
                selectedPlayerLevel = val;
                print("selectedPlayerLevel: $val");
              });
            },
          ),
        ),
      ],
    );
  }

  Padding buildTextField(
      {bool obscureText = false,
      String? heading,
      String? hintText,
      String? Function(String?)? validator,
      TextEditingController? controller,
      List<TextInputFormatter>? inputFormatters,
        Widget? suffixIcon,
      TextInputType? keyboardType = TextInputType.emailAddress}) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 60),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            heading!,
            style: AppStyles.getTextStyleGreyMB(false, 16),
          ),
          SizedBox(height: 10),
          Container(
            color: Colors.black54,
            child: TextFormField(
              cursorColor: Colors.white,
              obscureText: obscureText,
              controller: controller,
              keyboardType: keyboardType,
              inputFormatters: inputFormatters!,
              style: TextStyle(color: Colors.white),
              decoration: InputDecoration(
                suffixIcon: suffixIcon,
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.black54,
                  ),
                  gapPadding: 0.0,
                ),
                disabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.black54,
                  ),
                ),
                errorBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.black54,
                  ),
                ),
                focusedErrorBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.grey,
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.black54,
                  ),
                ),
                hintText: hintText,
                hintStyle: TextStyle(
                  fontFamily: 'Montserrat-SemiBold',
                  fontSize: 14.0,
                  color: Colors.white60,
                ),
                contentPadding: const EdgeInsets.symmetric(
                    vertical: 16.0, horizontal: 20.0),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Container buildSubmitButton(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width - 150,
      child: RaisedButton(
        elevation: 8.0,
        onPressed: onClick,
        color: materialAccentColor,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 14),
          child: DxTextWhiteM(
            'Register',
            mBold: true,
            mSize: 18,
          ),
        ),
      ),
    );
  }

  onClick() {
    UserModel userModel = UserModel(
      fullname: fullNameController.text,
      emailid: emailController.text,
      mobile: mobileController.text,
      keycol: passwordController.text,
      cPass: cPasswordController.text,
      playerlevel: selectedPlayerLevel,
    );
    BlocProvider.of<SignupCubit>(context).validation(userModel, context);
  }
}
