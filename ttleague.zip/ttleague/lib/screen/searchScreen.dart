import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:tt_league/Model/userModel.dart';
import 'package:tt_league/cubit/search/search_cubit.dart';
import 'package:tt_league/helper/app_utilities/colors.dart';
import 'package:tt_league/helper/app_utilities/method_utils.dart';
import 'package:tt_league/helper/app_utilities/size_reziser.dart';
import 'package:tt_league/helper/routeAndBlocManager/navigator.dart';
import 'package:tt_league/screen/subPages/playerDetail.dart';

import 'customWidget/dxWidget/dx_text.dart';

class SearchScreen extends StatefulWidget {
  static const routeName = 'search-screen';
  const SearchScreen({Key? key}) : super(key: key);

  @override
  _SearchScreenState createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  List<String> categories = ["Advanced", "Intermediate", "Basic","60+ "
      "Intermediate","60+ Advanced","Under 18","Under 15","Under 12"];
  final _scaffoldKey = GlobalKey<ScaffoldState>();
  String? _selectedFilter;

  @override
  void initState() {
    BlocProvider.of<SearchCubit>(context).refresh();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key:_scaffoldKey ,
      // backgroundColor: materialPrimaryColor,
      appBar: AppBar(
        elevation: 0,
      toolbarHeight: 120,
      automaticallyImplyLeading: false,
        title: Column(children: [
          SizedBox(height:5),
          DropdownButton(
            hint: DxTextWhite('Please choose a filter'),
            value: _selectedFilter,
            isExpanded: true,
            underline: Container(),
            onChanged: (newValue) {
              setState(() {
                _selectedFilter = newValue as String?;
              });
            },
            dropdownColor: Colors.black,
            items: categories.map((location) {
              return DropdownMenuItem(
                child: new DxTextWhite(location),
                value: location,
              );
            }).toList(),
          ),
          SizedBox(height: 5),
          Container(
            color: Colors.black54,
            margin: EdgeInsets.only(bottom: 8),
            child: TextFormField(
              cursorColor: Colors.white,
             onChanged: (v){
               if(_selectedFilter!=null){
                 BlocProvider.of<SearchCubit>(context).getSearchDetail(v,_selectedFilter!);
               }else{
                 MethodUtils.showSnackBarGK(_scaffoldKey, "Please choose a filter");
               }

             },
              style: TextStyle(color: Colors.white),
              decoration: InputDecoration(
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.black,
                  ),
                  gapPadding: 0.0,
                ),
                disabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.black,
                  ),
                ),
                errorBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.black,
                  ),
                ),
                focusedErrorBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.black,
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(
                    color: Colors.white,
                  ),
                ),
                hintText: "Search",
                hintStyle: TextStyle(
                  fontFamily: 'Montserrat-SemiBold',
                  fontSize: 14.0,
                  color: Colors.white60,
                ),
                contentPadding: const EdgeInsets.symmetric(
                    vertical: 16.0, horizontal: 20.0),
              ),
            ),
          ),
        ],),
        backgroundColor: black_grey,

      ),
      body: BlocConsumer<SearchCubit, SearchState>(
          builder: (BuildContext context, state) {
            if (state is SearchInitial) {
              return Center(child: Text("No Result Found!"),);
            }
            if (state is SearchLoaded) {

              return body(state.searchModel);
            }
            if (state is SearchError) {
              return Center(child: Text("No Result Found!"),);
            }

            return Container();
          }, listener: (BuildContext context, state) {
        if (state is SearchError) {
          MethodUtils.showSnackBarGK(_scaffoldKey, "${state.error}");
        }
      }),
    );
  }

  Widget body(List<UserModel> players) {
    return players.isEmpty ? Center(child: DxTextBlack("No Data Found!",
      mSize: 18,mBold: true,),) :
    GridView.builder(
      padding: const EdgeInsets.all(8),
      itemCount: players.length,
      physics: ClampingScrollPhysics(),
      shrinkWrap: true,
      itemBuilder: (BuildContext context, index) {
        return gridBody(players[index]);
      },
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 5.0,
          crossAxisSpacing: 5.0,
          childAspectRatio: 6 / 8),
    );
  }

  Widget gridBody(UserModel playerData) {
    String image = playerData.image1.split("/").last;
    return InkWell(
      onTap: ()=>openScreenAsLeftToRight(context,PlayerDetails(userModel:playerData)),
      child: Stack(
        children: [
          Container(
            height: 300,
            width: 250,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: CachedNetworkImage(imageUrl:"http://www"
                  ".sipconline.com/uat/sipl/images/$image",fit: BoxFit.cover,),
            ),
          ),
          Positioned(
              bottom: 10,
              left: 8,
              child: DxTextWhiteM(
                playerData.fullname!,
              )),
        ],
      ),
    );
  }

}
