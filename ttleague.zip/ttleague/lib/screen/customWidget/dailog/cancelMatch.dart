import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:tt_league/screen/customWidget/dxWidget/dx_text.dart';

class CancelMatch extends StatefulWidget {
  String matchId;
  String? msg;

  CancelMatch(this.matchId, {this.msg = "Cancel"});

  @override
  _CancelMatchState createState() => _CancelMatchState();
}

class _CancelMatchState extends State<CancelMatch> {
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      elevation: 0,
      backgroundColor: Colors.transparent,
      child: contentBox(context),
    );
  }

  contentBox(context) {
    return Container(
      height: 180,
      decoration: BoxDecoration(
          color: Colors.white, borderRadius: BorderRadius.circular(18)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          DxText(
            "Match ID: ${widget.matchId}",
            mBold: true,
            textColor: Colors.grey,
            mSize: 22,
          ),
          SizedBox(height: 10),
          DxTextBlack(
            "This match is ${widget.msg}",
            mSize: 20,
            mBold: true,
          ),
          SizedBox(height: 20),
          buildButton(context, onPressed: () {
            Navigator.pop(context);
          }, btnName: "OK")
        ],
      ),
    );
  }

  Container buildButton(BuildContext context,
      {String? btnName, required void Function()? onPressed}) {
    return Container(
      width: 150,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          stops: [0.1, 0.5, 0.7, 0.9],
          colors: [
            Color(0xffFF8960),
            Color(0xffFF8960),
            Color(0xffFF689A),
            Color(0xffFF689A),
          ],
        ),
      ),
      child: TextButton(
        onPressed: onPressed,
        child: DxTextWhiteM(
          btnName!,
          mBold: true,
          mSize: 20,
        ),
      ),
    );
  }
}
