import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:tt_league/helper/app_utilities/dx_app_decoration.dart';
import 'package:tt_league/screen/customWidget/dxWidget/dx_input_fields.dart';
import 'package:tt_league/screen/customWidget/dxWidget/dx_text.dart';

class EnterScrore extends StatefulWidget {
  @override
  _EnterScroreState createState() => _EnterScroreState();
}

class _EnterScroreState extends State<EnterScrore> {
  TextEditingController player1Score = TextEditingController();
  TextEditingController player2Score = TextEditingController();

  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      elevation: 0,
      backgroundColor: Colors.transparent,
      child: contentBox(context),
    );
  }

  contentBox(context) {
    return Container(
      height: 320,
      decoration: BoxDecoration(
          color: Colors.white,
        borderRadius: BorderRadius.circular(18)
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          DxText(
            "Match ID: ABC0111",
            mBold: true,
            textColor: Colors.grey,
            mSize: 22,
          ),
          SizedBox(height:10),
          DxTextBlack(
            "Player 1 - Ma Long",
            mSize: 20,
            mBold: true,
          ),
          SizedBox(height:12),
          // Container(
          //   height:75,
          //   child: DxInputText(
          //     keyboardType: TextInputType.text,
          //     autofocus: false,
          //     controller: player1Score,
          //     inputFormatters: [LengthLimitingTextInputFormatter(30)],
          //     valueText: player1Score.text,
          //     hintText: 'Enter Score',
          //     obscureText: true,
          //   ),
          //   color: Colors.white,
          // ),
          Container(
            width: 150,
            child: TextFormField(
              controller: player1Score,
              decoration: dxTextFieldDecoration(context, hint: "Enter Score"),
            ),
          ),
          SizedBox(
            height: 15,
          ),
          DxTextBlack(
            "Player 2 - Xu Xin",
            mSize: 20,
            mBold: true,
          ),
          SizedBox(
            height: 12,
          ),
          Container(
            width: 150,
            child: TextFormField(
              controller: player1Score,
              decoration: dxTextFieldDecoration(context, hint: "Enter Score"),
            ),
          ),
          SizedBox(height: 20),
          buildButton(context, onPressed: () {}, btnName: "OK")
        ],
      ),
    );
  }

  Container buildButton(BuildContext context,
      {String? btnName, required void Function()? onPressed}) {
    return Container(
      width: 150,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          stops: [0.1, 0.5, 0.7, 0.9],
          colors: [
            Color(0xffFF8960),
            Color(0xffFF8960),
            Color(0xffFF689A),
            Color(0xffFF689A),
          ],
        ),
      ),
      child: TextButton(
        onPressed: onPressed,
        child: DxTextWhiteM(
          btnName!,
          mBold: true,
          mSize: 20,
        ),
      ),
    );
  }
}
