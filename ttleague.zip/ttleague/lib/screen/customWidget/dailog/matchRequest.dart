import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'dart:ui' as ui;

import 'package:tt_league/helper/app_utilities/appImages.dart';
import 'package:tt_league/screen/customWidget/dxWidget/dx_text.dart';

class MatchRequest extends StatefulWidget {
  @override
  _MatchRequestState createState() => _MatchRequestState();
}

class _MatchRequestState extends State<MatchRequest> {
  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      elevation: 0,
      backgroundColor: Colors.transparent,
      child: contentBox(context),
    );
  }
  contentBox(context){
    return Container(
      height: 320,
     decoration: BoxDecoration(
       color: Colors.white,
       borderRadius: BorderRadius.circular(18)
     ),
      child: Column(
        children: [
        Stack(children: [
          Container(
            height: 150,
          ),
          Container(
            height: 130,
            width: double.infinity,
            // color: Colors.red,
            child: MyCurve(),
          ),
          Positioned(
            left: 0,
            right: 0,
            top: 75,
            child: Container(
              height: 85,
              width: 85,
              decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  // color: Colors.white,
                  border: Border.all(color: Colors.white),
                  image: DecorationImage(
                    fit: BoxFit.contain,
                    image: AssetImage(AppImages.player4)
                    // image: NetworkImage(
                    //     upsstudentsay.items![index].image ?? ""),
                  )),
            ),)
        ],),
          SizedBox(height: 15),
        DxTextBlack("Congratulations",mBold: true,mSize: 22,),
        SizedBox(height: 8),
        DxText("Your Match is Requested",mSize: 18,textColor: Colors.grey,),
        SizedBox(height: 20),
          buildButton(context, onPressed: () {
            Navigator.pop(context);
          }, btnName: "OK")

      ],),
    );
  }
  Container buildButton(BuildContext context,
      {String? btnName, required void Function()? onPressed}) {
    return Container(
      width: 150,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(30),
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          stops: [0.1, 0.5, 0.7, 0.9],
          colors: [
            Color(0xffFF8960),
            Color(0xffFF8960),
            Color(0xffFF689A),
            Color(0xffFF689A),
          ],
        ),
      ),
      child: TextButton(
        onPressed: onPressed,
        child: DxTextWhiteM(
          btnName!,
          mBold: true,
          mSize: 20,
        ),
      ),
    );
  }
}



//Add this CustomPaint widget to the Widget Tree
// CustomPaint(
// size: Size(WIDTH, (WIDTH*0.42857142857142855).toDouble()), //You can Replace [WIDTH] with your desired width for Custom Paint and height will be calculated automatically
// painter: RPSCustomPainter(),
// )

class MyCurve extends StatelessWidget {
final double widthMultiplier;
  const MyCurve({Key? key, this.widthMultiplier = 0.42857142857142855}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    MediaQueryData qData = MediaQuery.of(context);
    return CustomPaint(
      size: Size(qData.size.width, (qData.size.width*widthMultiplier).toDouble()), //You
      // can
      // Replace [WIDTH] with your desired width for Custom Paint and height will be calculated automatically
      painter: RPSCustomPainter(),
    );
  }
}


//Copy this CustomPainter code to the Bottom of the File
class RPSCustomPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {

    Path path_0 = Path();
    path_0.moveTo(0,size.height*0.1596623);
    path_0.lineTo(0,size.height*0.7828507);
    path_0.cubicTo(size.width*0.4372671,size.height*1.159662,size.width*0.8467888,size.height*0.9398551,size.width*0.9968944,size.height*0.7828507);
    path_0.cubicTo(size.width*0.9948261,size.height*0.5944449,size.width*0.9968944,size.height*0.1996797,size.width*0.9968944,size.height*0.1234304);
    path_0.cubicTo(size.width*0.9968944,size.height*0.04347870,size.width*0.9679068,size.height*0.01956565,size.width*0.9503106,size.height*0.01473478);
    path_0.lineTo(size.width*0.2484472,size.height*0.01473478);
    path_0.cubicTo(size.width*0.1956522,size.height*0.01473449,size.width*0.08074534,size.height*0.007246464,size.width*0.04658385,size.height*0.01473464);
    path_0.cubicTo(size.width*0.01186547,size.height*0.02234478,0,size.height*0.05797145,0,size.height*0.1596623);
    path_0.close();

    Paint paint_0_fill = Paint()..style=PaintingStyle.fill;
    paint_0_fill.shader = ui.Gradient.linear(Offset(size.width*0.1677019,size.height*0.3115942), Offset(size.width*0.7267081,size.height*0.6956522), [Color(0xffC960BC).withOpacity(1),Color(0xff8551E2).withOpacity(1),Color(0xff764EEA).withOpacity(1)], [0,0.775281,1]);
    canvas.drawPath(path_0,paint_0_fill);

  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }
}