import 'dart:async';
import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:tt_league/helper/app_utilities/app_theme.dart';
import 'dotIndicator.dart';

class ImageSliderWidget extends StatefulWidget {
  // final List<String> imageUrls;
  final List<String> allbanner;
  final BorderRadius imageBorderRadius;
  final double imageHeight;
  final double imagePadding;
  final double aspectRatio;
  final int activeIndex;
  final int delayTimeInSecond;
final bool loaderShow;
  const ImageSliderWidget({
    Key? key,
    // required this.imageUrls,
    required this.imageBorderRadius,
    required this.allbanner,
    this.imageHeight = 250.0,
    this.imagePadding = 2,
    this.activeIndex = 0,
    this.aspectRatio = 0,
    this.loaderShow = true,
    this.delayTimeInSecond = 5,
  }) : super(key: key);

  @override
  ImageSliderWidgetState createState() => ImageSliderWidgetState();
}

class ImageSliderWidgetState extends State<ImageSliderWidget> {
  List<Widget> _pages = [];

  int page = 0;
  int _currentPage = 0;

  final _controller = PageController();
  Timer? timer;

  @override
  void initState() {
    _currentPage = widget.activeIndex;
    _pages = widget.allbanner.map((banner) {
      return _buildImagePageItem(banner);
    }).toList();

    SchedulerBinding.instance!.addPostFrameCallback((_) {
      if (_controller.hasClients) {
        _controller.animateToPage(_currentPage,
            duration: Duration(milliseconds: 1), curve: Curves.easeIn);
        timer = Timer.periodic(Duration(seconds: widget.delayTimeInSecond),
                (Timer timer) {
              if (_currentPage < _pages.length - 1) {
                _currentPage++;
              } else {
                _currentPage = 0;
              }
              _controller.animateToPage(
                _currentPage,
                duration: Duration(milliseconds: 350),
                curve: Curves.easeIn,
              );
            });
      }
    });
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
    timer!.cancel();
  }

  @override
  Widget build(BuildContext context) {
    return _buildingImageSlider();
  }

  Widget _buildingImageSlider() {
    // return widget.imageHeight > 0
    //     ? AspectRatio(
    //   aspectRatio:
    //   widget.aspectRatio == 0 ? (24 / 12) : widget.aspectRatio,
    //   child: Container(
    //     color: Colors.yellow,
    //          height: widget.imageHeight,
    //     child: Card(
    //       shape: RoundedRectangleBorder(
    //           borderRadius: widget.imageBorderRadius),
    //       elevation: 0,
    //       child: Stack(
    //         children: [
    //           _buildPagerViewSlider(),
    //           _buildDotsIndicatorOverlay(),
    //         ],
    //       ),
    //     ),
    //   ),
    // )
    //     :
   return Container(
     height: widget.imageHeight,
      color: Colors.white,
      padding: EdgeInsets.all(widget.imagePadding),
      child: Stack(
        children: [
          _buildPagerViewSlider(),
        widget.loaderShow ?  _buildDotsIndicatorOverlay():Container(),
        ],
      ),
    );
  }

  Widget _buildPagerViewSlider() {
    return Positioned.fill(
      child: PageView.builder(
        physics: AlwaysScrollableScrollPhysics(),
        controller: _controller,
        itemCount: _pages.length,
        itemBuilder: (BuildContext context, int index) {
          return _pages[index % _pages.length];
        },
        onPageChanged: (int p) {
          setState(() {
            page = p;
            _currentPage = p;
          });
        },
      ),
    );
  }

  Positioned _buildDotsIndicatorOverlay() {
    return Positioned(
      top: 56.0,
      right: 0.0,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: DotsIndicator(
          controller: _controller,
          itemCount: _pages.length,
          onPageSelected: (int page) {
            _controller.animateToPage(
              page,
              duration: const Duration(milliseconds: 200),
              curve: Curves.ease,
            );
          },
        ),
      ),
    );
  }

  Widget _buildImagePageItem(String image) {
    //print("=>>"+imgUrl);
    return InkWell(
      onTap: (){

      },
      child: ClipRRect(
        borderRadius: widget.imageBorderRadius,
        child: image.startsWith("http")
            ? CachedNetworkImage(
          imageUrl: image,
          placeholder: (context, url) => Center(
            child: Platform.isIOS
                ? CupertinoActivityIndicator()
                : CircularProgressIndicator(),
          ),
          errorWidget: (context, url, error) => Icon(Icons.error),
          fit: BoxFit.fitWidth,
//        fit: widget.imageHeight > 0 ? BoxFit.cover : BoxFit.fitWidth,
        )
            : Image.asset(
          image,
          fit: BoxFit.cover,
          alignment: Alignment.center,
        ),
      ),
    );
  }

}
