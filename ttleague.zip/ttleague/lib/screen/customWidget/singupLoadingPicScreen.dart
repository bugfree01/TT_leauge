import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:tt_league/helper/app_utilities/appImages.dart';
import 'package:tt_league/helper/routeAndBlocManager/navigator.dart';
import 'package:tt_league/screen/customWidget/dxWidget/dx_text.dart';

import '../bottomNavigation.dart';
import 'bannerWidget/imageSlider.dart';

class SinupLoadingPics extends StatefulWidget {
  @override
  _SinupLoadingPicsState createState() => _SinupLoadingPicsState();
}

class _SinupLoadingPicsState extends State<SinupLoadingPics> {

  List<String> pics = [AppImages.videoPic2,AppImages
      .videoPic3,AppImages.videoPic4,AppImages.videoPic5,AppImages.videoPic6];

  int _currentPage = 0;

@override
  void initState() {
    // TODO: implement initState
  // startTimer();
  super.initState();
  }

  void startTimer() {
    Future.delayed(Duration(seconds: 6), () => navigateInside());
  }

  void navigateInside() async {
      openScreenAsPlatformWiseRoute(context, BottomNavigation(),
          isExit: true);
  }

  _onchanged(int index) {
    setState(() {
      _currentPage = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      // body: Container(
      //   child:  ImageSliderWidget(
      //       imageHeight: size.height,
      //       imagePadding: 0,
      //       allbanner: pics,
      //       loaderShow: false,
      //       delayTimeInSecond:1,
      //       imageBorderRadius: BorderRadius.circular(10)),
      // ),
      body: Stack(children: [
        PageView.builder(
            itemCount: pics.length,
            onPageChanged: _onchanged,
            itemBuilder: (context,i){
          return Container(
            height: size.height,
            width: size.width,
            child: Image.asset(pics[i],fit: BoxFit.cover,),
          );
        }),

        Positioned(
          bottom: 10,
          right: 10,
          child: TextButton(
            child: DxTextWhite("Skip",mBold: true,mSize: 18,),
            onPressed: navigateInside,
          ),
        ), Positioned(
          bottom: 30,
          right: 1,
          left: 1,
          child:    Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List<Widget>.generate(pics.length, (int index) {
                return AnimatedContainer(
                    duration: Duration(milliseconds: 300),
                    height: 10,
                    width: (index == _currentPage) ? 30 : 10,
                    margin:
                    EdgeInsets.symmetric(horizontal: 5, vertical: 30),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5),
                        color: (index == _currentPage)
                            ? Colors.white
                            : Colors.white.withOpacity(0.5)));
              })),
        )
      ],),
    );
  }
}
