class PrefKeys {
  PrefKeys._();

  static String get localPin => '_localPin';

  static String get isDownloaded => '_isDownloaded';

  static String get userType => '_userType';

  static String get userId => '_userId';
  static String get gender => '_gender';

  static String get cartLink => '_cart';

  static String get fbLink => '_fb';

  static String get instaLink => '_insta';

  static String get updateData => '_UpdateData ';

  static String get linkedInLink => '_linked';

  static String get twitterLink => '_twitter';

  static String get wishlistLink => '_wishlist';

  static String get testing => '_testing';


  static String get sideNavigation => '_SideNavigation';

  static String get updates => '_uupdate';

  static String get userPassword => 'sideNavigation';

  static String get userName => '_userName';

  static String get playerLevel => '_playerLevel';
  static String get shirtReddem => '_shirtRedeem';

  static String get playerImage => '_playerImage';
  static String get playerImage1 => '_playerImag1e';
  static String get playerImage2 => '_playerImage2';
  static String get playerImage3 => '_playerImage3';
  static String get playerImage4 => '_playerImage4';
  static String get playerImage5 => '_playerImage5';

  static String get wins => '_wins';

  static String get matches => '_matches';

  static String get winsPercentage => '_winsPercentage';

  static String get credit => '_credit';

  static String get eCredit => '_Ecredit';

  static String get Time => '_time';
  static String get pLocate => '_pLocate';

  static String get location => '_location';

  static String get aboutME => '_aboutME';

  static String get cart => '_cart';
  static String get age => '_age';
  static String get gwin => '_gwin';
  static String get swin => '_swin';
  static String get bwin => '_bwin';
  static String get shirt => '_shirt';


  static String get userFullName => '_userFullName';

  static String get userEmail => '_userEmail';

  static String get userMobile => '_userMobile';

  static String get userAddress => '_userAddress';

  static String get userCity => '_userCity';

  static String get userState => '_userState';

  static String get token => '_companyCode';

  static String get drId => '_drId';

  static String get userProfilePic => '_userProfilePic';

  static String get localNotifStorage => '_localNotifStorage_';

  static String get keyDeviceToken_ => '_deviceToken_';
}
